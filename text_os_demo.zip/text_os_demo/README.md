# XinWei

XinWei，寓意新纬度。

这是一个沉浸式文本操作系统原型。当前版本重点修复品牌观感，包含软件名，图标，启动页，边缘到边缘显示，首次引导，主题切换，游客状态，设置入口和基础书架。

## 当前版本

V4.2 外观修复版。

## GitHub Actions 必要步骤

在 `flutter pub get` 之后，`flutter build apk` 之前运行：

```bash
dart run flutter_launcher_icons
dart run flutter_native_splash:create
```

如果需要修改 Android 显示名称：

```bash
sed -i 's/android:label="[^"]*"/android:label="XinWei"/' android/app/src/main/AndroidManifest.xml
```
