# XinWei

新纬度，沉浸式文本操作系统。

当前版本包含：首次引导，主题切换，游客模式，响应式书架，本地持久化测试书，阅读流，角色档案，设置页。

打包注意：需要在 GitHub Actions 中运行 flutter_launcher_icons，并把 Android label 改成 XinWei。
