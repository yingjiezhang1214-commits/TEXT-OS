# Text OS Demo V3

V3 commercial-grade static shell.

Features:
- First-run onboarding.
- Guest-first app model.
- Dark, light, and system theme modes.
- Four primary pages: bookshelf, reader, character profiles, settings.
- GPT-style feed layout and floating input console.
- Settings second-level pages as product placeholders.
- Local-first privacy copy.

No real TXT import, API calls, login, or AI generation yet.
