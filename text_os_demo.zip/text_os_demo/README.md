# Text OS Demo V2

A static Flutter shell prototype for a ChatGPT-like immersive text operating system.
