import 'dart:async';
import 'package:flutter/material.dart';

import '../data/mock_story.dart';
import '../engine/signal_bus.dart';
import '../engine/typewriter_controller.dart';
import '../fx/fx_channels_manager.dart';
import '../fx/fx_render_layer.dart';
import '../models/engine_event.dart';
import '../models/story_block.dart';

class ReaderView extends StatefulWidget {
  final LocalStoryBlock initialBlock;

  const ReaderView({super.key, required this.initialBlock});

  @override
  State<ReaderView> createState() => _ReaderViewState();
}

class _ReaderViewState extends State<ReaderView> with SingleTickerProviderStateMixin {
  late final SignalBus _signalBus;
  late final FxChannelsManager _fxManager;
  late final AnimationController _flashController;
  late final StreamSubscription<EngineEvent> _engineSub;

  late TypewriterController _typewriter;
  late LocalStoryBlock _currentBlock;

  bool _isComplete = false;

  @override
  void initState() {
    super.initState();

    _currentBlock = widget.initialBlock;
    _signalBus = SignalBus();
    _fxManager = FxChannelsManager(_signalBus);
    _flashController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _engineSub = _signalBus.eventStream.listen((event) {
      if (!mounted) return;

      if (event is BlockCompleteEvent) {
        setState(() => _isComplete = true);
      } else if (event is ResetAllEvent) {
        setState(() => _isComplete = false);
      }
    });

    _typewriter = TypewriterController(block: _currentBlock, signalBus: _signalBus);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _typewriter.start();
    });
  }

  Future<void> _jumpToMirrorWorld() async {
    if (!_isComplete) return;

    _typewriter.stopAndReset();
    _flashController.value = 1.0;

    await Future.delayed(const Duration(milliseconds: 50));
    if (!mounted) return;

    final oldController = _typewriter;
    final newBlock = MockStory.mirrorBlock;
    final newController = TypewriterController(block: newBlock, signalBus: _signalBus);

    setState(() {
      _currentBlock = newBlock;
      _typewriter = newController;
      _isComplete = false;
    });

    oldController.dispose();

    _flashController.reverse();

    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;

    _typewriter.start();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          RepaintBoundary(
            child: FxRenderLayer(
              manager: _fxManager,
              signalStream: _signalBus.eventStream,
            ),
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.topLeft,
              child: IconButton(
                onPressed: () => Navigator.of(context).maybePop(),
                icon: const Icon(Icons.close, color: Colors.white38),
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40.0),
              child: ValueListenableBuilder<String>(
                valueListenable: _typewriter.visibleTextNotifier,
                builder: (context, visibleText, _) {
                  return AnimatedOpacity(
                    opacity: visibleText.isEmpty ? 0.0 : 1.0,
                    duration: const Duration(milliseconds: 220),
                    child: Text(
                      visibleText,
                      textAlign: TextAlign.left,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        height: 1.85,
                        letterSpacing: 0.8,
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          Positioned(
            bottom: 78,
            left: 0,
            right: 0,
            child: Center(
              child: AbsorbPointer(
                absorbing: !_isComplete,
                child: AnimatedOpacity(
                  opacity: _isComplete ? 1.0 : 0.0,
                  duration: const Duration(milliseconds: 1000),
                  child: OutlinedButton(
                    onPressed: _isComplete ? _jumpToMirrorWorld : null,
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Colors.white54),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                    ),
                    child: const Text('进入平行世界'),
                  ),
                ),
              ),
            ),
          ),
          IgnorePointer(
            child: FadeTransition(
              opacity: CurvedAnimation(
                parent: _flashController,
                curve: Curves.easeOutCubic,
              ),
              child: Container(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _engineSub.cancel();
    _typewriter.dispose();
    _flashController.dispose();
    _fxManager.dispose();
    _signalBus.dispose();
    super.dispose();
  }
}
