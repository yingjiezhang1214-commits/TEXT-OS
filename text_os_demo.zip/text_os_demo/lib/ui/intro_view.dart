import 'package:flutter/material.dart';
import 'dashboard_view.dart';

class IntroView extends StatefulWidget {
  const IntroView({super.key});

  @override
  State<IntroView> createState() => _IntroViewState();
}

class _IntroViewState extends State<IntroView> {
  final List<String> _pages = const [
    '一本普通小说，其实是一个沉浸的世界。',
    '文字不只被阅读，也可以被感知。',
    '风，沉默，转身，都会在屏幕里留下回声。',
    '进入一个更安静的文本系统。',
  ];

  int _index = 0;
  double _opacity = 1.0;

  Future<void> _next() async {
    setState(() => _opacity = 0.0);
    await Future.delayed(const Duration(milliseconds: 350));
    if (!mounted) return;

    if (_index < _pages.length - 1) {
      setState(() {
        _index++;
        _opacity = 1.0;
      });
      return;
    }

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 1500),
        pageBuilder: (_, __, ___) => const DashboardView(),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _next,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 38),
            child: AnimatedOpacity(
              opacity: _opacity,
              duration: const Duration(milliseconds: 450),
              child: Text(
                _pages[_index],
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 18,
                  height: 1.8,
                  letterSpacing: 1.2,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
