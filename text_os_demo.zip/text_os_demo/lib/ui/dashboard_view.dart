import 'package:flutter/material.dart';
import '../data/mock_story.dart';
import 'reader_view.dart';

class DashboardView extends StatelessWidget {
  const DashboardView({super.key});

  void _openReader(BuildContext context) {
    Navigator.of(context).push(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 900),
        pageBuilder: (_, __, ___) => ReaderView(initialBlock: MockStory.canonBlock),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Center(
              child: GestureDetector(
                onTap: () => _openReader(context),
                child: Container(
                  width: 260,
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 34),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white24),
                    borderRadius: BorderRadius.circular(22),
                    color: Colors.white.withOpacity(0.03),
                  ),
                  child: const Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '弘大街头',
                        style: TextStyle(color: Colors.white, fontSize: 22, letterSpacing: 2),
                      ),
                      SizedBox(height: 14),
                      Text(
                        '本地硬编码测试文本',
                        style: TextStyle(color: Colors.white38, fontSize: 13),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 42,
              left: 28,
              right: 28,
              child: OutlinedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Phase 1 暂不导入文件，先跑通沉浸式阅读闭环。')),
                  );
                },
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Colors.white24),
                  foregroundColor: Colors.white54,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text('+ 导入本地文本'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
