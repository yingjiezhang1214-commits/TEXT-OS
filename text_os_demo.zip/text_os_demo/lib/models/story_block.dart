import 'anchor.dart';

class LocalStoryBlock {
  final String blockId;
  final String pureText;
  final List<Anchor> anchors;
  final String? nextBlockId;

  const LocalStoryBlock({
    required this.blockId,
    required this.pureText,
    required this.anchors,
    this.nextBlockId,
  });
}
