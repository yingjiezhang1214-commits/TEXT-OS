import 'anchor.dart';

sealed class EngineEvent {
  const EngineEvent();
}

final class BlockEnterEvent extends EngineEvent {
  final String blockId;
  const BlockEnterEvent(this.blockId);
}

final class FxSignalEvent extends EngineEvent {
  final Anchor anchor;
  const FxSignalEvent(this.anchor);
}

final class BlockCompleteEvent extends EngineEvent {
  const BlockCompleteEvent();
}

final class ResetAllEvent extends EngineEvent {
  const ResetAllEvent();
}
