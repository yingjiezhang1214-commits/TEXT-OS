enum FxChannel { PARTICLE, BLUR, MATRIX, TYPOGRAPHY, NOISE, BRIGHTNESS }

enum RestoreMode { SMOOTH, IMMEDIATE, DECAY }

class Anchor {
  final String triggerWord;
  final int triggerGraphemeIndex;
  final String signalType;
  final FxChannel channel;
  final double intensity;
  final int durationMs;
  final RestoreMode restoreMode;

  const Anchor({
    required this.triggerWord,
    required this.triggerGraphemeIndex,
    required this.signalType,
    required this.channel,
    required this.intensity,
    required this.durationMs,
    required this.restoreMode,
  });
}
