import 'package:characters/characters.dart';
import '../models/anchor.dart';
import '../data/static_lexicon.dart';

class AnchorScanner {
  static List<Anchor> scan(String pureText) {
    final List<Anchor> results = [];
    final graphemes = pureText.characters.toList();

    if (graphemes.isEmpty) return results;

    lexicon.forEach((triggerWord, config) {
      final wordGraphemes = triggerWord.characters.toList();
      if (wordGraphemes.isEmpty) return;

      for (int i = 0; i <= graphemes.length - wordGraphemes.length; i++) {
        var isMatch = true;

        for (int j = 0; j < wordGraphemes.length; j++) {
          if (graphemes[i + j] != wordGraphemes[j]) {
            isMatch = false;
            break;
          }
        }

        if (isMatch) {
          final triggerIndex = i + wordGraphemes.length - 1;
          results.add(Anchor(
            triggerWord: triggerWord,
            triggerGraphemeIndex: triggerIndex,
            signalType: config.signalType,
            channel: config.channel,
            intensity: config.intensity,
            durationMs: config.durationMs,
            restoreMode: config.restoreMode,
          ));
        }
      }
    });

    results.sort((a, b) {
      final indexCmp = a.triggerGraphemeIndex.compareTo(b.triggerGraphemeIndex);
      if (indexCmp != 0) return indexCmp;

      if (a.channel == FxChannel.TYPOGRAPHY && b.channel != FxChannel.TYPOGRAPHY) return -1;
      if (b.channel == FxChannel.TYPOGRAPHY && a.channel != FxChannel.TYPOGRAPHY) return 1;
      return 0;
    });

    return results;
  }
}
