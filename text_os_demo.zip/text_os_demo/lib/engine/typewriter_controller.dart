import 'dart:async';
import 'package:characters/characters.dart';
import 'package:flutter/foundation.dart';

import '../models/anchor.dart';
import '../models/story_block.dart';
import 'signal_bus.dart';

class TypewriterController {
  final LocalStoryBlock block;
  final SignalBus signalBus;

  final ValueNotifier<String> visibleTextNotifier = ValueNotifier<String>('');

  int _currentGraphemeIndex = 0;
  Timer? _tickerTimer;
  final Set<Timer> _activeTypographyTimers = {};

  final double _baseSpeedMs = 50.0;
  double _speedMultiplier = 1.0;

  bool _isRunning = false;
  bool _isDisposed = false;

  late final List<String> _graphemes;
  late final Map<int, List<Anchor>> _anchorMap;

  TypewriterController({
    required this.block,
    required this.signalBus,
  }) {
    _graphemes = block.pureText.characters.toList();
    _initAnchorMap();
  }

  void _initAnchorMap() {
    _anchorMap = {};
    for (final anchor in block.anchors) {
      _anchorMap.putIfAbsent(anchor.triggerGraphemeIndex, () => []).add(anchor);
    }
  }

  void start() {
    if (_isDisposed || _isRunning) return;
    _isRunning = true;
    signalBus.emitBlockEnter(block.blockId);
    _currentGraphemeIndex = 0;
    _tick();
  }

  void _tick() {
    if (_isDisposed || !_isRunning) return;

    if (_currentGraphemeIndex >= _graphemes.length) {
      _tickerTimer?.cancel();
      _isRunning = false;
      signalBus.emitBlockComplete();
      return;
    }

    visibleTextNotifier.value = _graphemes.sublist(0, _currentGraphemeIndex + 1).join();

    final hitAnchors = _anchorMap[_currentGraphemeIndex];
    if (hitAnchors != null) {
      for (final anchor in hitAnchors) {
        _executeAnchor(anchor);
      }
    }

    _currentGraphemeIndex++;
    final nextIntervalMs = (_baseSpeedMs * _speedMultiplier).round().clamp(16, 1000);
    _tickerTimer = Timer(Duration(milliseconds: nextIntervalMs), _tick);
  }

  void _executeAnchor(Anchor anchor) {
    if (_isDisposed) return;

    if (anchor.channel == FxChannel.TYPOGRAPHY) {
      _speedMultiplier = anchor.intensity;

      if (anchor.durationMs > 0) {
        late Timer recoveryTimer;
        recoveryTimer = Timer(Duration(milliseconds: anchor.durationMs), () {
          if (_isDisposed) return;
          _speedMultiplier = 1.0;
          _activeTypographyTimers.remove(recoveryTimer);
        });
        _activeTypographyTimers.add(recoveryTimer);
      }
    }

    signalBus.emitSignal(anchor);
  }

  void stopAndReset() {
    if (_isDisposed) return;

    _isRunning = false;
    _tickerTimer?.cancel();
    _tickerTimer = null;

    for (final timer in _activeTypographyTimers) {
      timer.cancel();
    }
    _activeTypographyTimers.clear();

    _speedMultiplier = 1.0;
    _currentGraphemeIndex = 0;
    visibleTextNotifier.value = '';

    signalBus.emitResetAll();
  }

  void dispose() {
    if (_isDisposed) return;
    stopAndReset();
    _isDisposed = true;
    visibleTextNotifier.dispose();
  }
}
