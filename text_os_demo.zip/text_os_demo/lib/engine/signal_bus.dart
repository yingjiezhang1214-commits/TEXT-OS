import 'dart:async';
import '../models/anchor.dart';
import '../models/engine_event.dart';

class SignalBus {
  final StreamController<EngineEvent> _controller = StreamController<EngineEvent>.broadcast();

  Stream<EngineEvent> get eventStream => _controller.stream;

  void emitBlockEnter(String blockId) {
    if (!_controller.isClosed) _controller.add(BlockEnterEvent(blockId));
  }

  void emitSignal(Anchor anchor) {
    if (!_controller.isClosed) _controller.add(FxSignalEvent(anchor));
  }

  void emitBlockComplete() {
    if (!_controller.isClosed) _controller.add(const BlockCompleteEvent());
  }

  void emitResetAll() {
    if (!_controller.isClosed) _controller.add(const ResetAllEvent());
  }

  void dispose() {
    _controller.close();
  }
}
