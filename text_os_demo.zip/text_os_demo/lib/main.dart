import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final hasSeenOnboarding = prefs.getBool('has_seen_onboarding') ?? false;
  final themeIndex = prefs.getInt('theme_mode') ?? ThemeMode.system.index;
  final initialTheme = ThemeMode.values[themeIndex.clamp(0, ThemeMode.values.length - 1)];

  runApp(TextOSApp(
    prefs: prefs,
    hasSeenOnboarding: hasSeenOnboarding,
    initialThemeMode: initialTheme,
  ));
}

class TextOSApp extends StatefulWidget {
  final SharedPreferences prefs;
  final bool hasSeenOnboarding;
  final ThemeMode initialThemeMode;

  const TextOSApp({
    super.key,
    required this.prefs,
    required this.hasSeenOnboarding,
    required this.initialThemeMode,
  });

  @override
  State<TextOSApp> createState() => _TextOSAppState();
}

class _TextOSAppState extends State<TextOSApp> {
  late ThemeMode _themeMode;
  late bool _hasSeenOnboarding;

  @override
  void initState() {
    super.initState();
    _themeMode = widget.initialThemeMode;
    _hasSeenOnboarding = widget.hasSeenOnboarding;
  }

  Future<void> _setThemeMode(ThemeMode mode) async {
    setState(() => _themeMode = mode);
    await widget.prefs.setInt('theme_mode', mode.index);
  }

  Future<void> _finishOnboarding() async {
    await widget.prefs.setBool('has_seen_onboarding', true);
    setState(() => _hasSeenOnboarding = true);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: _themeMode,
      home: _hasSeenOnboarding
          ? V3AppShell(
              currentThemeMode: _themeMode,
              onThemeModeChanged: _setThemeMode,
            )
          : ViewOnboarding(onFinish: _finishOnboarding),
    );
  }
}

class AppColors {
  static const darkBg = Color(0xFF000000);
  static const darkSurface = Color(0xFF0A0A0A);
  static const darkSurfaceElevated = Color(0xFF141414);
  static const darkBorder = Color(0xFF1C1C1C);
  static const darkTextMain = Color(0xFFE8E8E8);
  static const darkTextSub = Color(0xFF737373);

  static const lightBg = Color(0xFFF6F6F3);
  static const lightSurface = Color(0xFFFFFFFF);
  static const lightSurfaceElevated = Color(0xFFEEEEEA);
  static const lightBorder = Color(0xFFE2E2DD);
  static const lightTextMain = Color(0xFF1E1E1C);
  static const lightTextSub = Color(0xFF7C7C77);
}

class AppTheme {
  static ThemeData get dark => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.darkBg,
        fontFamily: 'sans-serif',
        colorScheme: const ColorScheme.dark(
          surface: AppColors.darkSurface,
          onSurface: AppColors.darkTextMain,
          outline: AppColors.darkBorder,
          primary: AppColors.darkTextMain,
          secondary: AppColors.darkTextSub,
        ),
      );

  static ThemeData get light => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: AppColors.lightBg,
        fontFamily: 'sans-serif',
        colorScheme: const ColorScheme.light(
          surface: AppColors.lightSurface,
          onSurface: AppColors.lightTextMain,
          outline: AppColors.lightBorder,
          primary: AppColors.lightTextMain,
          secondary: AppColors.lightTextSub,
        ),
      );
}

class Tokens {
  static bool isDark(BuildContext context) => Theme.of(context).brightness == Brightness.dark;
  static Color bg(BuildContext context) => Theme.of(context).scaffoldBackgroundColor;
  static Color surface(BuildContext context) => Theme.of(context).colorScheme.surface;
  static Color text(BuildContext context) => Theme.of(context).colorScheme.onSurface;
  static Color subText(BuildContext context) => Theme.of(context).colorScheme.secondary;
  static Color border(BuildContext context) => Theme.of(context).colorScheme.outline;

  static Color elevated(BuildContext context) => isDark(context) ? AppColors.darkSurfaceElevated : AppColors.lightSurfaceElevated;
  static Color appBarTint(BuildContext context) => bg(context).withOpacity(isDark(context) ? 0.62 : 0.78);
  static Color shadow(BuildContext context) => Colors.black.withOpacity(isDark(context) ? 0.70 : 0.09);
  static Color chip(BuildContext context) => text(context).withOpacity(isDark(context) ? 0.08 : 0.06);
}

// ==========================================
// Onboarding
// ==========================================
class ViewOnboarding extends StatefulWidget {
  final Future<void> Function() onFinish;

  const ViewOnboarding({super.key, required this.onFinish});

  @override
  State<ViewOnboarding> createState() => _ViewOnboardingState();
}

class _ViewOnboardingState extends State<ViewOnboarding> {
  final PageController _pageController = PageController();
  int _page = 0;
  bool _leaving = false;

  Future<void> _finish() async {
    if (_leaving) return;
    _leaving = true;
    await widget.onFinish();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);

    return Scaffold(
      body: Stack(
        children: [
          PageView(
            controller: _pageController,
            onPageChanged: (value) => setState(() => _page = value),
            children: const [
              _OnboardingPage(
                title: '文本即世界',
                desc: '导入一部本地小说，\n系统会把静态段落组织成可交互的信息流。',
              ),
              _OnboardingPage(
                title: '正史与平行',
                desc: '你可以安静阅读原文，\n也可以从某一刻切入镜像世界。',
              ),
              _OnboardingPage(
                title: '文本即私有领地',
                desc: '所有导入的本地小说默认绝不上传。\n只有你主动触发 AI 功能时，相关上下文片段才会发送至你配置的节点。',
              ),
            ],
          ),
          Positioned(
            left: 32,
            right: 32,
            bottom: MediaQuery.of(context).padding.bottom + 40,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 260),
              child: _page == 2
                  ? Column(
                      key: const ValueKey('finish'),
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _PrimaryCapsuleButton(label: '先体验示例世界', onTap: _finish),
                        const SizedBox(height: 16),
                        GestureDetector(
                          onTap: _finish,
                          child: Text('稍后导入本地文本', style: TextStyle(color: text.withOpacity(0.42), fontSize: 13)),
                        ),
                      ],
                    )
                  : Row(
                      key: const ValueKey('next'),
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextButton(onPressed: _finish, child: Text('跳过', style: TextStyle(color: text.withOpacity(0.42)))),
                        GestureDetector(
                          onTap: () => _pageController.nextPage(
                            duration: const Duration(milliseconds: 320),
                            curve: Curves.easeOutCubic,
                          ),
                          child: Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(color: text.withOpacity(0.10), shape: BoxShape.circle),
                            child: Icon(Icons.arrow_forward_rounded, color: text, size: 21),
                          ),
                        ),
                      ],
                    ),
            ),
          ),
          Positioned(
            bottom: MediaQuery.of(context).padding.bottom + 112,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(3, (index) {
                final active = index == _page;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 240),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: active ? 18 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: text.withOpacity(active ? 0.7 : 0.18),
                    borderRadius: BorderRadius.circular(999),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}

class _OnboardingPage extends StatelessWidget {
  final String title;
  final String desc;

  const _OnboardingPage({required this.title, required this.desc});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(width: 38, height: 4, decoration: BoxDecoration(color: text, borderRadius: BorderRadius.circular(999))),
          const SizedBox(height: 28),
          Text(title, style: TextStyle(color: text, fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: .5)),
          const SizedBox(height: 18),
          Text(desc, style: TextStyle(color: text.withOpacity(0.52), fontSize: 15.5, height: 1.8)),
        ],
      ),
    );
  }
}

class _PrimaryCapsuleButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _PrimaryCapsuleButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    final bg = Tokens.bg(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(color: text, borderRadius: BorderRadius.circular(26)),
        child: Center(child: Text(label, style: TextStyle(color: bg, fontSize: 14, fontWeight: FontWeight.w700))),
      ),
    );
  }
}

// ==========================================
// App shell
// ==========================================
enum AppPage { home, reader, characters, settings }

class V3AppShell extends StatefulWidget {
  final ThemeMode currentThemeMode;
  final Future<void> Function(ThemeMode mode) onThemeModeChanged;

  const V3AppShell({super.key, required this.currentThemeMode, required this.onThemeModeChanged});

  @override
  State<V3AppShell> createState() => _V3AppShellState();
}

class _V3AppShellState extends State<V3AppShell> with SingleTickerProviderStateMixin {
  AppPage _page = AppPage.home;
  bool _showMirror = false;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final ScrollController _readerScroll = ScrollController();
  late final AnimationController _flashController;

  @override
  void initState() {
    super.initState();
    _flashController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
  }

  void _go(AppPage page) {
    setState(() {
      _page = page;
      if (page != AppPage.reader) _showMirror = false;
    });
  }

  void _openBookHub() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(Tokens.isDark(context) ? 0.65 : 0.20),
      builder: (sheetContext) => _BookHubSheet(
        onContinue: () {
          Navigator.pop(sheetContext);
          _go(AppPage.reader);
        },
        onCreateCharacter: () {
          Navigator.pop(sheetContext);
          _go(AppPage.characters);
        },
        onWorldline: () {
          Navigator.pop(sheetContext);
          _go(AppPage.reader);
          setState(() => _showMirror = true);
        },
      ),
    );
  }

  Future<void> _triggerParallelWorld() async {
    if (_showMirror) return;
    _flashController.value = 1.0;
    await Future.delayed(const Duration(milliseconds: 30));
    if (!mounted) return;

    setState(() => _showMirror = true);
    _flashController.reverse();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_readerScroll.hasClients) return;
      _readerScroll.animateTo(
        _readerScroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 780),
        curve: Curves.fastOutSlowIn,
      );
    });
  }

  @override
  void dispose() {
    _readerScroll.dispose();
    _flashController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Tokens.bg(context),
      extendBodyBehindAppBar: true,
      resizeToAvoidBottomInset: true,
      drawer: V3Drawer(
        page: _page,
        onNavigate: (page) {
          Navigator.pop(context);
          _go(page);
        },
        onLoginTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('云同步功能开发中'))),
      ),
      appBar: _buildAppBar(context),
      body: Stack(
        children: [
          _buildBody(context),
          if (_page == AppPage.reader)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Padding(
                padding: EdgeInsets.fromLTRB(18, 0, 18, MediaQuery.of(context).padding.bottom + 14),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedOpacity(
                      opacity: _showMirror ? 0 : 1,
                      duration: const Duration(milliseconds: 360),
                      child: IgnorePointer(
                        ignoring: _showMirror,
                        child: _ParallelChip(onTap: _triggerParallelWorld),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const V3InputConsole(),
                  ],
                ),
              ),
            ),
          IgnorePointer(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _flashController, curve: Curves.easeOutCubic),
              child: Container(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    final title = switch (_page) {
      AppPage.home => '书架',
      AppPage.reader => '弘大街头.txt',
      AppPage.characters => '角色档案',
      AppPage.settings => '系统偏好',
    };
    final text = Tokens.text(context);
    return PreferredSize(
      preferredSize: const Size.fromHeight(kToolbarHeight),
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: AppBar(
            backgroundColor: Tokens.appBarTint(context),
            elevation: 0,
            scrolledUnderElevation: 0,
            leading: IconButton(
              icon: Icon(Icons.menu_rounded, color: text.withOpacity(0.50), size: 22),
              onPressed: () => _scaffoldKey.currentState?.openDrawer(),
            ),
            centerTitle: true,
            title: Text(title, style: TextStyle(color: text.withOpacity(0.54), fontSize: 13, letterSpacing: .5)),
            actions: [
              if (_page == AppPage.reader)
                Padding(
                  padding: const EdgeInsets.only(right: 16),
                  child: Center(
                    child: Text(_showMirror ? '镜像' : '正史', style: TextStyle(color: text.withOpacity(_showMirror ? 0.72 : 0.35), fontSize: 11)),
                  ),
                )
              else
                const SizedBox(width: 12),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context) {
    return switch (_page) {
      AppPage.home => ViewHome(onOpenBook: _openBookHub),
      AppPage.reader => ViewReader(scrollController: _readerScroll, showMirror: _showMirror),
      AppPage.characters => const ViewCharacters(),
      AppPage.settings => ViewSettings(
          currentThemeMode: widget.currentThemeMode,
          onThemeModeChanged: widget.onThemeModeChanged,
        ),
    };
  }
}

// ==========================================
// Drawer
// ==========================================
class V3Drawer extends StatelessWidget {
  final AppPage page;
  final ValueChanged<AppPage> onNavigate;
  final VoidCallback onLoginTap;

  const V3Drawer({super.key, required this.page, required this.onNavigate, required this.onLoginTap});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return Drawer(
      backgroundColor: Tokens.isDark(context) ? const Color(0xFF050505) : const Color(0xFFF1F1EE),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 28, 24, 18),
              child: Text('TEXT OS', style: TextStyle(color: text.withOpacity(0.55), fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 2.4)),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                children: [
                  _drawerTitle(context, '主要'),
                  _drawerItem(context, Icons.library_books_outlined, '书架', AppPage.home),
                  _drawerItem(context, Icons.timeline_rounded, '世界线', AppPage.reader),
                  const SizedBox(height: 12),
                  _drawerTitle(context, '演绎'),
                  _drawerItem(context, Icons.person_outline_rounded, '角色档案', AppPage.characters),
                  const SizedBox(height: 12),
                  _drawerTitle(context, '系统'),
                  _drawerItem(context, Icons.tune_rounded, '设置', AppPage.settings),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 18),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Tokens.elevated(context),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Tokens.border(context)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: text.withOpacity(0.10)),
                      child: Icon(Icons.person_rounded, color: text.withOpacity(0.52), size: 18),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('游客模式', style: TextStyle(color: text.withOpacity(0.78), fontSize: 13, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 2),
                          Text('本地阅读可完整使用', style: TextStyle(color: text.withOpacity(0.38), fontSize: 11)),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: onLoginTap,
                      child: Text('登录', style: TextStyle(color: text.withOpacity(0.65), fontSize: 12)),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _drawerTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      child: Text(title, style: TextStyle(color: Tokens.text(context).withOpacity(0.28), fontSize: 11, fontWeight: FontWeight.w700)),
    );
  }

  Widget _drawerItem(BuildContext context, IconData icon, String title, AppPage target) {
    final active = target == page;
    final text = Tokens.text(context);
    return ListTile(
      onTap: () => onNavigate(target),
      dense: true,
      visualDensity: VisualDensity.compact,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
      tileColor: active ? text.withOpacity(Tokens.isDark(context) ? 0.08 : 0.06) : Colors.transparent,
      leading: Icon(icon, color: text.withOpacity(active ? 0.72 : 0.32), size: 19),
      title: Text(title, style: TextStyle(color: text.withOpacity(active ? 0.82 : 0.52), fontSize: 13, fontWeight: active ? FontWeight.w600 : FontWeight.w400)),
    );
  }
}

// ==========================================
// Home
// ==========================================
class ViewHome extends StatelessWidget {
  final VoidCallback onOpenBook;

  const ViewHome({super.key, required this.onOpenBook});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return ListView(
      padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 22, left: 20, right: 20, bottom: 32),
      children: [
        Text('最近阅读', style: TextStyle(color: text.withOpacity(0.48), fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: .5)),
        const SizedBox(height: 14),
        GestureDetector(
          onTap: onOpenBook,
          child: _BookCard(),
        ),
        const SizedBox(height: 24),
        _HomeActionCard(icon: Icons.add_rounded, title: '导入本地小说', desc: 'TXT，EPUB，长文本文件', onTap: () {}),
        const SizedBox(height: 12),
        _HomeActionCard(icon: Icons.person_add_alt_1_rounded, title: '从头创建角色', desc: '选择小说后，从第一章进入新世界线', onTap: onOpenBook),
      ],
    );
  }
}

class _BookCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Tokens.surface(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Tokens.border(context)),
        boxShadow: [BoxShadow(color: Tokens.shadow(context), blurRadius: 20, offset: const Offset(0, 6))],
      ),
      child: Row(
        children: [
          Container(
            width: 70,
            height: 96,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: Tokens.isDark(context)
                    ? [const Color(0xFF1A1A1A), const Color(0xFF050505)]
                    : [const Color(0xFFFFFFFF), const Color(0xFFE8E8E2)],
              ),
              border: Border.all(color: Tokens.border(context)),
            ),
            child: Center(child: Icon(Icons.menu_book_rounded, color: text.withOpacity(0.40), size: 26)),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('弘大街头', style: TextStyle(color: text, fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text('阅读进度 12% · 2 条世界线 · 1 个角色档案', style: TextStyle(color: text.withOpacity(0.42), fontSize: 12, height: 1.5)),
                const SizedBox(height: 16),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: .12,
                    minHeight: 4,
                    backgroundColor: text.withOpacity(0.10),
                    valueColor: AlwaysStoppedAnimation<Color>(text.withOpacity(0.72)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String desc;
  final VoidCallback onTap;

  const _HomeActionCard({required this.icon, required this.title, required this.desc, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Tokens.surface(context), borderRadius: BorderRadius.circular(16), border: Border.all(color: Tokens.border(context))),
        child: Row(
          children: [
            Icon(icon, color: text.withOpacity(0.62), size: 22),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(color: text.withOpacity(0.82), fontSize: 14, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 3),
                  Text(desc, style: TextStyle(color: text.withOpacity(0.38), fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BookHubSheet extends StatelessWidget {
  final VoidCallback onContinue;
  final VoidCallback onCreateCharacter;
  final VoidCallback onWorldline;

  const _BookHubSheet({required this.onContinue, required this.onCreateCharacter, required this.onWorldline});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return Container(
      padding: EdgeInsets.fromLTRB(22, 18, 22, MediaQuery.of(context).padding.bottom + 22),
      decoration: BoxDecoration(
        color: Tokens.surface(context),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(top: BorderSide(color: Tokens.border(context))),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(width: 36, height: 4, decoration: BoxDecoration(color: text.withOpacity(0.18), borderRadius: BorderRadius.circular(999))),
          ),
          const SizedBox(height: 22),
          Text('弘大街头.txt', style: TextStyle(color: text, fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text('正史进度 12% · 镜像线 2 条 · 角色档案 1 个', style: TextStyle(color: text.withOpacity(0.42), fontSize: 12)),
          const SizedBox(height: 22),
          _ModeCard(icon: Icons.play_arrow_rounded, title: '继续阅读正史', desc: '从上次离开的自然段继续', onTap: onContinue),
          const SizedBox(height: 12),
          _ModeCard(icon: Icons.person_add_alt_1_rounded, title: '从头创建角色', desc: '以新身份从第一章进入世界', onTap: onCreateCharacter),
          const SizedBox(height: 12),
          _ModeCard(icon: Icons.timeline_rounded, title: '进入已有世界线', desc: '继续上次的平行演绎记录', onTap: onWorldline),
        ],
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String desc;
  final VoidCallback onTap;

  const _ModeCard({required this.icon, required this.title, required this.desc, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Tokens.elevated(context),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Tokens.border(context)),
        ),
        child: Row(
          children: [
            Icon(icon, color: text.withOpacity(0.70), size: 22),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(color: text.withOpacity(0.86), fontSize: 14, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(desc, style: TextStyle(color: text.withOpacity(0.40), fontSize: 11)),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// Reader
// ==========================================
class ViewReader extends StatelessWidget {
  final ScrollController scrollController;
  final bool showMirror;

  const ViewReader({super.key, required this.scrollController, required this.showMirror});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return ListView(
      controller: scrollController,
      padding: EdgeInsets.only(
        top: kToolbarHeight + MediaQuery.of(context).padding.top + 24,
        bottom: 180,
        left: 20,
        right: 20,
      ),
      children: [
        _SystemLine(label: '场景已转换：弘大街头'),
        const SizedBox(height: 24),
        _CanonCard(text: '那晚弘大街头的风很凉，他突然在人群中转过身。这里陷入了长久的沉默。'),
        if (showMirror) ...[
          const SizedBox(height: 30),
          _SystemLine(label: '世界线已偏移'),
          const SizedBox(height: 22),
          _MirrorCard(text: '世界线已偏移。他低下头，孤身走向了那场没有终点的暴雨。你意识到，从这一刻开始，正史只会安静地停留在身后。'),
          const SizedBox(height: 18),
          _ChoiceRow(labels: const ['靠近他', '保持旁观', '询问真相']),
        ],
        const SizedBox(height: 40),
        Center(child: Text(showMirror ? '镜像演绎已开启' : '当前处于正史阅读', style: TextStyle(color: text.withOpacity(0.25), fontSize: 11))),
      ],
    );
  }
}

class _SystemLine extends StatelessWidget {
  final String label;

  const _SystemLine({required this.label});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(color: Tokens.chip(context), borderRadius: BorderRadius.circular(999)),
        child: Text('— $label —', style: TextStyle(color: Tokens.text(context).withOpacity(0.36), fontSize: 10.5, letterSpacing: 1.2)),
      ),
    );
  }
}

class _CanonCard extends StatelessWidget {
  final String text;

  const _CanonCard({required this.text});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(color: Tokens.text(context).withOpacity(0.88), fontSize: 16.5, height: 1.82, letterSpacing: .3, fontFamily: 'serif'),
    );
  }
}

class _MirrorCard extends StatelessWidget {
  final String text;

  const _MirrorCard({required this.text});

  @override
  Widget build(BuildContext context) {
    final main = Tokens.text(context);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Tokens.elevated(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: main.withOpacity(0.13)),
        boxShadow: [BoxShadow(color: Tokens.shadow(context), blurRadius: 24, offset: const Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Mirror World 001', style: TextStyle(color: main.withOpacity(0.44), fontSize: 11, letterSpacing: 1.2, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          Text(text, style: TextStyle(color: main.withOpacity(0.88), fontSize: 15.5, height: 1.75)),
        ],
      ),
    );
  }
}

class _ChoiceRow extends StatelessWidget {
  final List<String> labels;

  const _ChoiceRow({required this.labels});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: labels.map((label) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: BoxDecoration(color: Tokens.chip(context), borderRadius: BorderRadius.circular(999), border: Border.all(color: Tokens.border(context))),
          child: Text(label, style: TextStyle(color: text.withOpacity(0.72), fontSize: 12)),
        );
      }).toList(),
    );
  }
}

class _ParallelChip extends StatelessWidget {
  final VoidCallback onTap;

  const _ParallelChip({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: Tokens.chip(context),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Tokens.border(context), width: .8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.auto_awesome_rounded, color: text.withOpacity(0.70), size: 13),
            const SizedBox(width: 6),
            Text('开启平行世界', style: TextStyle(color: text.withOpacity(0.70), fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: .3)),
          ],
        ),
      ),
    );
  }
}

class V3InputConsole extends StatelessWidget {
  const V3InputConsole({super.key});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: Tokens.surface(context),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Tokens.border(context), width: 1),
        boxShadow: [BoxShadow(color: Tokens.shadow(context), blurRadius: 22, offset: const Offset(0, 8))],
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(shape: BoxShape.circle, color: text.withOpacity(0.08)),
            child: Icon(Icons.add_rounded, color: text.withOpacity(0.70), size: 22),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text('向这个世界输入行动…', style: TextStyle(color: text.withOpacity(0.38), fontSize: 13.5))),
          Icon(Icons.mic_none_rounded, color: text.withOpacity(0.42), size: 21),
          const SizedBox(width: 10),
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(shape: BoxShape.circle, color: text.withOpacity(0.90)),
            child: Icon(Icons.graphic_eq_rounded, color: Tokens.bg(context), size: 20),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// Characters
// ==========================================
class ViewCharacters extends StatelessWidget {
  const ViewCharacters({super.key});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return ListView(
      padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 22, left: 20, right: 20, bottom: 36),
      children: [
        Text('角色档案', style: TextStyle(color: text.withOpacity(0.48), fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 14),
        _CharacterCard(name: '未命名旅人', role: '旁观者 · 可切换为新角色', traits: '谨慎，观察力高，不主动干涉正史'),
        const SizedBox(height: 12),
        _CharacterCard(name: '新建角色档案', role: '从头重生模式使用', traits: '姓名，身份，阵营，能力，关系网'),
      ],
    );
  }
}

class _CharacterCard extends StatelessWidget {
  final String name;
  final String role;
  final String traits;

  const _CharacterCard({required this.name, required this.role, required this.traits});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: Tokens.surface(context), borderRadius: BorderRadius.circular(18), border: Border.all(color: Tokens.border(context))),
      child: Row(
        children: [
          Container(width: 48, height: 48, decoration: BoxDecoration(shape: BoxShape.circle, color: text.withOpacity(0.08)), child: Icon(Icons.person_outline_rounded, color: text.withOpacity(0.52))),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: TextStyle(color: text.withOpacity(0.86), fontSize: 15, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(role, style: TextStyle(color: text.withOpacity(0.44), fontSize: 12)),
              const SizedBox(height: 6),
              Text(traits, style: TextStyle(color: text.withOpacity(0.34), fontSize: 11, height: 1.4)),
            ]),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// Settings
// ==========================================
class ViewSettings extends StatelessWidget {
  final ThemeMode currentThemeMode;
  final Future<void> Function(ThemeMode mode) onThemeModeChanged;

  const ViewSettings({super.key, required this.currentThemeMode, required this.onThemeModeChanged});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return ListView(
      padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 22, left: 20, right: 20, bottom: 36),
      children: [
        Text('系统偏好', style: TextStyle(color: text.withOpacity(0.48), fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 14),
        _SettingTile(
          icon: Icons.contrast_rounded,
          title: '外观模式',
          desc: _themeLabel(currentThemeMode),
          onTap: () => _showAppearanceSheet(context),
        ),
        _SettingTile(icon: Icons.text_fields_rounded, title: '阅读与排版', desc: '字号，行距，段距，卡片宽度', onTap: () => _showPlaceholderSheet(context, '阅读与排版')),
        _SettingTile(icon: Icons.vibration_rounded, title: '动画与马达', desc: '动效强度，震动，低性能模式，高刷模式', onTap: () => _showPlaceholderSheet(context, '动画与马达')),
        _SettingTile(icon: Icons.api_rounded, title: 'AI 接入', desc: 'Provider，API Key，Endpoint，模型选择', onTap: () => _showPlaceholderSheet(context, 'AI 接入')),
        _SettingTile(icon: Icons.auto_awesome_rounded, title: '平行世界规则', desc: '正史忠诚度，自由度，选项数量，生成长度', onTap: () => _showPlaceholderSheet(context, '平行世界规则')),
        _SettingTile(icon: Icons.lock_outline_rounded, title: '数据与隐私', desc: '本地缓存，导入导出，请求记录', onTap: () => _showPrivacySheet(context)),
      ],
    );
  }

  String _themeLabel(ThemeMode mode) {
    return switch (mode) {
      ThemeMode.system => '跟随系统',
      ThemeMode.light => '浅色模式',
      ThemeMode.dark => '深色模式',
    };
  }

  void _showAppearanceSheet(BuildContext context) {
    _showBaseSheet(
      context,
      title: '外观模式',
      children: [
        _ThemeOption(label: '跟随系统', mode: ThemeMode.system, current: currentThemeMode, onTap: onThemeModeChanged),
        _ThemeOption(label: '浅色模式', mode: ThemeMode.light, current: currentThemeMode, onTap: onThemeModeChanged),
        _ThemeOption(label: '深色模式', mode: ThemeMode.dark, current: currentThemeMode, onTap: onThemeModeChanged),
      ],
    );
  }

  void _showPlaceholderSheet(BuildContext context, String title) {
    _showBaseSheet(
      context,
      title: title,
      children: [
        _SheetLine('此处将承载 $title 的二级配置。'),
        _SheetLine('当前版本先保留入口与产品结构。'),
        _SheetLine('后续接入真实解析器，AI 网关与存档系统。'),
      ],
    );
  }

  void _showPrivacySheet(BuildContext context) {
    _showBaseSheet(
      context,
      title: '数据与隐私',
      children: const [
        _SheetLine('本地小说默认只在设备端处理，不会自动上传。'),
        _SheetLine('只有你主动使用 AI 功能时，才会发送必要上下文片段。'),
        _SheetLine('未来会提供请求记录开关，缓存清理与存档导出。'),
      ],
    );
  }

  void _showBaseSheet(BuildContext context, {required String title, required List<Widget> children}) {
    final text = Tokens.text(context);
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: EdgeInsets.fromLTRB(22, 18, 22, MediaQuery.of(context).padding.bottom + 22),
        decoration: BoxDecoration(
          color: Tokens.surface(context),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(top: BorderSide(color: Tokens.border(context))),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Container(width: 36, height: 4, decoration: BoxDecoration(color: text.withOpacity(0.18), borderRadius: BorderRadius.circular(999)))),
            const SizedBox(height: 22),
            Text(title, style: TextStyle(color: text, fontSize: 19, fontWeight: FontWeight.w800)),
            const SizedBox(height: 18),
            ...children,
          ],
        ),
      ),
    );
  }
}

class _SettingTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String desc;
  final VoidCallback onTap;

  const _SettingTile({required this.icon, required this.title, required this.desc, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Tokens.surface(context), borderRadius: BorderRadius.circular(16), border: Border.all(color: Tokens.border(context))),
          child: Row(
            children: [
              Icon(icon, color: text.withOpacity(0.62), size: 21),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, style: TextStyle(color: text.withOpacity(0.84), fontSize: 14, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(desc, style: TextStyle(color: text.withOpacity(0.38), fontSize: 11)),
                ]),
              ),
              Icon(Icons.chevron_right_rounded, color: text.withOpacity(0.22), size: 22),
            ],
          ),
        ),
      ),
    );
  }
}

class _ThemeOption extends StatelessWidget {
  final String label;
  final ThemeMode mode;
  final ThemeMode current;
  final Future<void> Function(ThemeMode mode) onTap;

  const _ThemeOption({required this.label, required this.mode, required this.current, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final text = Tokens.text(context);
    final active = mode == current;
    return GestureDetector(
      onTap: () => onTap(mode),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: active ? Tokens.elevated(context) : Tokens.surface(context), borderRadius: BorderRadius.circular(15), border: Border.all(color: active ? text.withOpacity(0.20) : Tokens.border(context))),
        child: Row(
          children: [
            Icon(active ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, color: text.withOpacity(active ? 0.75 : 0.35), size: 20),
            const SizedBox(width: 12),
            Text(label, style: TextStyle(color: text.withOpacity(active ? 0.86 : 0.58), fontSize: 14, fontWeight: active ? FontWeight.w700 : FontWeight.w400)),
          ],
        ),
      ),
    );
  }
}

class _SheetLine extends StatelessWidget {
  final String text;

  const _SheetLine(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(text, style: TextStyle(color: Tokens.text(context).withOpacity(0.48), fontSize: 13, height: 1.55)),
    );
  }
}
