import 'dart:ui';
import 'package:flutter/material.dart';

void main() => runApp(const TextOSV2Engine());

class TextOSV2Engine extends StatelessWidget {
  const TextOSV2Engine({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.black,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: const V2AppShell(),
    );
  }
}

enum AppPage { home, reader, characters, settings }

class V2AppShell extends StatefulWidget {
  const V2AppShell({super.key});

  @override
  State<V2AppShell> createState() => _V2AppShellState();
}

class _V2AppShellState extends State<V2AppShell>
    with SingleTickerProviderStateMixin {
  AppPage _currentPage = AppPage.home;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final ScrollController _scrollController = ScrollController();
  late final AnimationController _flashController;
  bool _showMirror = false;

  @override
  void initState() {
    super.initState();
    _flashController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
  }

  void _navigateTo(AppPage page) {
    setState(() {
      _currentPage = page;
      if (page != AppPage.reader) _showMirror = false;
    });
  }

  void _openBookHub() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111111),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (sheetContext) => _BookHubSheet(
        onContinueReading: () {
          Navigator.pop(sheetContext);
          _navigateTo(AppPage.reader);
        },
        onCreateCharacter: () {
          Navigator.pop(sheetContext);
          _navigateTo(AppPage.characters);
        },
        onOpenWorldLine: () {
          Navigator.pop(sheetContext);
          setState(() {
            _currentPage = AppPage.reader;
            _showMirror = true;
          });
          WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
        },
      ),
    );
  }

  Future<void> _triggerParallelWorld() async {
    if (_showMirror) return;
    _flashController.value = 1.0;
    await Future.delayed(const Duration(milliseconds: 30));
    if (!mounted) return;
    setState(() => _showMirror = true);
    _flashController.reverse();
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
  }

  void _scrollToBottom() {
    if (!mounted || !_scrollController.hasClients) return;
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 800),
      curve: Curves.fastOutSlowIn,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      resizeToAvoidBottomInset: true,
      drawer: V2Drawer(
        currentPage: _currentPage,
        onNavigate: (page) {
          Navigator.pop(context);
          _navigateTo(page);
        },
      ),
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          _buildBody(),
          if (_currentPage == AppPage.reader)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: V2ReaderDock(
                showMirror: _showMirror,
                onOpenMirror: _triggerParallelWorld,
              ),
            ),
          IgnorePointer(
            child: FadeTransition(
              opacity: CurvedAnimation(
                parent: _flashController,
                curve: Curves.easeOutCubic,
              ),
              child: Container(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    final title = switch (_currentPage) {
      AppPage.home => '书架',
      AppPage.reader => '弘大街头.txt',
      AppPage.characters => '角色档案',
      AppPage.settings => '系统偏好设置',
    };

    return PreferredSize(
      preferredSize: const Size.fromHeight(kToolbarHeight),
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: AppBar(
            backgroundColor: Colors.black.withOpacity(0.40),
            elevation: 0,
            scrolledUnderElevation: 0,
            leading: IconButton(
              icon: const Icon(
                Icons.align_horizontal_left_rounded,
                color: Colors.white38,
                size: 20,
              ),
              onPressed: () => _scaffoldKey.currentState?.openDrawer(),
            ),
            centerTitle: true,
            title: Text(
              title,
              style: const TextStyle(
                color: Colors.white54,
                fontSize: 13,
                letterSpacing: 0.5,
                fontWeight: FontWeight.w500,
              ),
            ),
            actions: _currentPage == AppPage.reader
                ? [
                    Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: Center(
                        child: _ModeBadge(label: _showMirror ? '镜像' : '正史'),
                      ),
                    ),
                  ]
                : null,
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    return switch (_currentPage) {
      AppPage.home => ViewHome(onOpenBook: _openBookHub),
      AppPage.reader => ViewReader(
          scrollController: _scrollController,
          showMirror: _showMirror,
        ),
      AppPage.characters => const ViewCharacters(),
      AppPage.settings => const ViewSettings(),
    };
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _flashController.dispose();
    super.dispose();
  }
}

class _ModeBadge extends StatelessWidget {
  final String label;
  const _ModeBadge({required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 5,
          height: 5,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: label == '镜像' ? Colors.white70 : Colors.white38,
            boxShadow: label == '镜像'
                ? [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.35),
                      blurRadius: 8,
                    ),
                  ]
                : null,
          ),
        ),
        const SizedBox(width: 6),
        Text(label, style: const TextStyle(color: Colors.white30, fontSize: 11)),
      ],
    );
  }
}

class V2Drawer extends StatelessWidget {
  final AppPage currentPage;
  final ValueChanged<AppPage> onNavigate;

  const V2Drawer({super.key, required this.currentPage, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFF060606),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(24, 28, 24, 16),
              child: Text(
                'TEXT OS',
                style: TextStyle(
                  color: Colors.white38,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  _section('核心'),
                  _item(Icons.library_books_rounded, '书架', AppPage.home),
                  _item(Icons.menu_book_rounded, '阅读流', AppPage.reader),
                  _section('演绎'),
                  _item(Icons.person_outline_rounded, '角色档案', AppPage.characters),
                  _section('系统'),
                  _item(Icons.tune_rounded, '设置', AppPage.settings),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(20),
              child: Text(
                'V2 static shell · no AI connected',
                style: TextStyle(color: Colors.white24, fontSize: 10),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 12, top: 14, bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
          color: Colors.white24,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _item(IconData icon, String title, AppPage page) {
    final active = currentPage == page;
    return ListTile(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      tileColor: active ? const Color(0xFF141414) : Colors.transparent,
      leading: Icon(icon, color: active ? Colors.white70 : Colors.white24, size: 18),
      title: Text(
        title,
        style: TextStyle(
          color: active ? Colors.white70 : Colors.white38,
          fontSize: 13,
        ),
      ),
      dense: true,
      onTap: () => onNavigate(page),
    );
  }
}

class ViewHome extends StatelessWidget {
  final VoidCallback onOpenBook;
  const ViewHome({super.key, required this.onOpenBook});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.only(
        top: kToolbarHeight + MediaQuery.of(context).padding.top + 24,
        left: 20,
        right: 20,
        bottom: 32,
      ),
      children: [
        const Text(
          '最近文本',
          style: TextStyle(color: Colors.white38, fontSize: 12, letterSpacing: 1),
        ),
        const SizedBox(height: 14),
        GestureDetector(
          onTap: onOpenBook,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF0A0A0A),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFF1A1A1A)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.45),
                  blurRadius: 24,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '弘大街头',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  '阅读进度 12% · 2 条世界线 · 1 个角色档案',
                  style: TextStyle(color: Colors.white38, fontSize: 12),
                ),
                SizedBox(height: 18),
                Row(
                  children: [
                    _MiniPill('继续阅读'),
                    SizedBox(width: 8),
                    _MiniPill('创建角色'),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 22),
        _HomeEmptyAction(
          icon: Icons.add_rounded,
          title: '载入本地文本',
          subtitle: '未来支持 TXT 自动解析与章节识别',
        ),
      ],
    );
  }
}

class _MiniPill extends StatelessWidget {
  final String text;
  const _MiniPill(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      child: Text(text, style: const TextStyle(color: Colors.white54, fontSize: 11)),
    );
  }
}

class _HomeEmptyAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _HomeEmptyAction({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF050505),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF141414)),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white30, size: 20),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white54, fontSize: 13)),
                const SizedBox(height: 3),
                Text(subtitle, style: const TextStyle(color: Colors.white24, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BookHubSheet extends StatelessWidget {
  final VoidCallback onContinueReading;
  final VoidCallback onCreateCharacter;
  final VoidCallback onOpenWorldLine;

  const _BookHubSheet({
    required this.onContinueReading,
    required this.onCreateCharacter,
    required this.onOpenWorldLine,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(22, 22, 22, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '弘大街头.txt',
              style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 5),
            const Text(
              '选择进入方式',
              style: TextStyle(color: Colors.white38, fontSize: 12),
            ),
            const SizedBox(height: 22),
            _ModeCard(
              icon: Icons.play_arrow_rounded,
              title: '继续观测正史',
              subtitle: '从上次离开的段落继续阅读',
              onTap: onContinueReading,
            ),
            const SizedBox(height: 12),
            _ModeCard(
              icon: Icons.person_add_alt_1_rounded,
              title: '从头创建角色',
              subtitle: '用自建身份进入这个世界',
              onTap: onCreateCharacter,
            ),
            const SizedBox(height: 12),
            _ModeCard(
              icon: Icons.timeline_rounded,
              title: '进入已有世界线',
              subtitle: '继续一条已经偏移的镜像剧情',
              onTap: onOpenWorldLine,
            ),
          ],
        ),
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ModeCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1A),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white10),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white70, size: 23),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: Colors.white, fontSize: 14)),
                  const SizedBox(height: 3),
                  Text(subtitle, style: const TextStyle(color: Colors.white38, fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ViewReader extends StatelessWidget {
  final ScrollController scrollController;
  final bool showMirror;

  const ViewReader({
    super.key,
    required this.scrollController,
    required this.showMirror,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      controller: scrollController,
      padding: EdgeInsets.only(
        top: kToolbarHeight + MediaQuery.of(context).padding.top + 26,
        bottom: 190,
        left: 20,
        right: 20,
      ),
      children: [
        const _SystemCard('场景已转换：弘大街头'),
        const SizedBox(height: 24),
        const _CanonCard(
          '那晚弘大街头的风很凉，他突然在人群中转过身。这里陷入了长久的沉默。',
        ),
        if (showMirror) ...[
          const SizedBox(height: 28),
          const _SystemCard('世界线已偏移'),
          const SizedBox(height: 22),
          const _MirrorCard(
            '世界线已偏移。他低下头，孤身走向了那场没有终点的暴雨。',
          ),
        ],
      ],
    );
  }
}

class _SystemCard extends StatelessWidget {
  final String message;
  const _SystemCard(this.message);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        '—— $message ——',
        style: const TextStyle(
          color: Color(0xFF444444),
          fontSize: 10,
          letterSpacing: 1.4,
        ),
      ),
    );
  }
}

class _CanonCard extends StatelessWidget {
  final String text;
  const _CanonCard(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF070707),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF171717)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Color(0xFFE4E4E4),
          fontSize: 16.5,
          height: 1.82,
          letterSpacing: 0.25,
          fontFamily: 'serif',
        ),
      ),
    );
  }
}

class _MirrorCard extends StatelessWidget {
  final String text;
  const _MirrorCard(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF101010),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.16)),
        boxShadow: [
          BoxShadow(
            color: Colors.white.withOpacity(0.045),
            blurRadius: 28,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'MIRROR WORLD 001',
            style: TextStyle(color: Colors.white30, fontSize: 10, letterSpacing: 1.5),
          ),
          const SizedBox(height: 12),
          Text(
            text,
            style: const TextStyle(
              color: Color(0xFFEAEAEA),
              fontSize: 16.5,
              height: 1.82,
              letterSpacing: 0.25,
              fontFamily: 'serif',
            ),
          ),
        ],
      ),
    );
  }
}

class V2ReaderDock extends StatelessWidget {
  final bool showMirror;
  final VoidCallback onOpenMirror;

  const V2ReaderDock({
    super.key,
    required this.showMirror,
    required this.onOpenMirror,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(18, 0, 18, MediaQuery.of(context).padding.bottom + 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedOpacity(
            opacity: !showMirror ? 1.0 : 0.0,
            duration: const Duration(milliseconds: 500),
            child: IgnorePointer(
              ignoring: showMirror,
              child: GestureDetector(
                onTap: onOpenMirror,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white12, width: 0.8),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.auto_awesome_rounded, color: Colors.white70, size: 13),
                      SizedBox(width: 6),
                      Text(
                        '开启平行世界',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          V2InputConsole(showMirror: showMirror),
        ],
      ),
    );
  }
}

class V2InputConsole extends StatelessWidget {
  final bool showMirror;
  const V2InputConsole({super.key, required this.showMirror});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      padding: const EdgeInsets.only(left: 16, right: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0F0F),
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: const Color(0xFF1C1C1C), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.72),
            blurRadius: 22,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              showMirror ? '输入你在镜像世界中的行动…' : '询问这段文本，或继续阅读…',
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white30, fontSize: 13),
            ),
          ),
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white10),
            ),
            child: Icon(
              showMirror ? Icons.arrow_upward_rounded : Icons.arrow_forward_rounded,
              color: Colors.white54,
              size: 18,
            ),
          ),
        ],
      ),
    );
  }
}

class ViewCharacters extends StatelessWidget {
  const ViewCharacters({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.only(
        top: kToolbarHeight + MediaQuery.of(context).padding.top + 24,
        left: 20,
        right: 20,
        bottom: 36,
      ),
      children: const [
        _SectionHeader('角色档案'),
        SizedBox(height: 14),
        _CharacterCard(),
        SizedBox(height: 14),
        _PlaceholderCard(
          icon: Icons.add_rounded,
          title: '创建新角色',
          subtitle: '未来可配置身份、阵营、能力、与原著人物关系',
        ),
      ],
    );
  }
}

class _CharacterCard extends StatelessWidget {
  const _CharacterCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF1A1A1A)),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('默认档案 · 旁观者', style: TextStyle(color: Colors.white, fontSize: 15)),
          SizedBox(height: 8),
          Text('身份：异乡路人 · 风格：低干预 · 正史忠诚度：高',
              style: TextStyle(color: Colors.white38, fontSize: 12, height: 1.6)),
        ],
      ),
    );
  }
}

class ViewSettings extends StatelessWidget {
  const ViewSettings({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.only(
        top: kToolbarHeight + MediaQuery.of(context).padding.top + 24,
        left: 20,
        right: 20,
        bottom: 36,
      ),
      children: const [
        _SectionHeader('系统偏好'),
        SizedBox(height: 14),
        _SettingsTile(Icons.text_fields_rounded, '阅读设置', '字体大小、行距、段落间距、流式速度'),
        _SettingsTile(Icons.animation_rounded, '动画与马达', '动效强度、震动、白闪、低性能模式、高刷模式'),
        _SettingsTile(Icons.api_rounded, 'AI 接入', 'API Key、模型选择、自定义 Endpoint、备用模型'),
        _SettingsTile(Icons.timeline_rounded, '平行世界规则', '正史忠诚度、AI 自由度、选项数量、生成长度'),
        _SettingsTile(Icons.person_outline_rounded, '角色默认值', '默认身份、性格、能力、与世界观关系'),
        _SettingsTile(Icons.storage_rounded, '数据与隐私', '缓存、导入导出存档、请求记录、清除世界线'),
      ],
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(color: Colors.white38, fontSize: 12, letterSpacing: 1),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _SettingsTile(this.icon, this.title, this.subtitle);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF181818)),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white38, size: 20),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white70, fontSize: 13.5)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: Colors.white24, fontSize: 11.5)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: Colors.white24, size: 18),
        ],
      ),
    );
  }
}

class _PlaceholderCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _PlaceholderCard({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF050505),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF141414)),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white30, size: 20),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white54, fontSize: 13)),
                const SizedBox(height: 3),
                Text(subtitle, style: const TextStyle(color: Colors.white24, fontSize: 11.5, height: 1.4)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
