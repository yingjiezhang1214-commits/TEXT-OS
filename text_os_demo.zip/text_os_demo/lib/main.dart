import 'package:flutter/material.dart';
import 'ui/intro_view.dart';

void main() => runApp(const TextOSEngine());

class TextOSEngine extends StatelessWidget {
  const TextOSEngine({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.black,
        brightness: Brightness.dark,
        fontFamily: 'monospace',
        useMaterial3: true,
      ),
      home: const IntroView(),
    );
  }
}
