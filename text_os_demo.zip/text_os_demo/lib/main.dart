import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final database = await LocalDatabase.open();
  runApp(TextOSApp(prefs: prefs, database: database));
}

// =============================================================
// Theme tokens
// =============================================================
class AppTheme {
  static ThemeData get dark => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF000000),
        fontFamily: 'sans-serif',
        colorScheme: const ColorScheme.dark(
          surface: Color(0xFF0A0A0A),
          surfaceContainerHighest: Color(0xFF141414),
          onSurface: Color(0xFFE6E6E6),
          outline: Color(0xFF1E1E1E),
          primary: Color(0xFFFFFFFF),
        ),
      );

  static ThemeData get light => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF7F7F5),
        fontFamily: 'sans-serif',
        colorScheme: const ColorScheme.light(
          surface: Color(0xFFFFFFFF),
          surfaceContainerHighest: Color(0xFFEFEFED),
          onSurface: Color(0xFF202020),
          outline: Color(0xFFE1E1DF),
          primary: Color(0xFF111111),
        ),
      );
}

ThemeMode themeModeFromInt(int value) {
  switch (value) {
    case 1:
      return ThemeMode.light;
    case 2:
      return ThemeMode.dark;
    default:
      return ThemeMode.system;
  }
}

int themeModeToInt(ThemeMode mode) {
  switch (mode) {
    case ThemeMode.light:
      return 1;
    case ThemeMode.dark:
      return 2;
    case ThemeMode.system:
      return 0;
  }
}

// =============================================================
// SQLite persistence layer, V4.1
// =============================================================
class BookModel {
  final int id;
  final String title;
  final String filePath;
  final String fileNameHash;
  final String encoding;
  final int importTime;
  final int? lastReadTime;

  const BookModel({
    required this.id,
    required this.title,
    required this.filePath,
    required this.fileNameHash,
    required this.encoding,
    required this.importTime,
    required this.lastReadTime,
  });

  factory BookModel.fromMap(Map<String, Object?> map) {
    return BookModel(
      id: map['id'] as int,
      title: map['title'] as String,
      filePath: map['file_path'] as String,
      fileNameHash: map['file_name_hash'] as String,
      encoding: map['encoding'] as String,
      importTime: map['import_time'] as int,
      lastReadTime: map['last_read_time'] as int?,
    );
  }
}

class ChapterDraft {
  final int index;
  final String title;
  final int startByteOffset;
  final int endByteOffset;
  final int wordCount;

  const ChapterDraft({
    required this.index,
    required this.title,
    required this.startByteOffset,
    required this.endByteOffset,
    required this.wordCount,
  });
}

class ImportResult {
  final String title;
  final String filePath;
  final String fileHash;
  final String encoding;
  final List<ChapterDraft> chapters;

  const ImportResult({
    required this.title,
    required this.filePath,
    required this.fileHash,
    required this.encoding,
    required this.chapters,
  });
}

class LocalDatabase {
  final Database _db;
  final StreamController<List<BookModel>> _booksController = StreamController<List<BookModel>>.broadcast();

  LocalDatabase._(this._db);

  static Future<LocalDatabase> open() async {
    final dbPath = await getDatabasesPath();
    final filePath = p.join(dbPath, 'xinwei_v41.sqlite');
    final db = await openDatabase(
      filePath,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            file_path TEXT NOT NULL,
            file_name_hash TEXT NOT NULL UNIQUE,
            encoding TEXT NOT NULL DEFAULT 'utf8',
            import_time INTEGER NOT NULL,
            last_read_time INTEGER
          )
        ''');

        await db.execute('''
          CREATE TABLE chapters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            chapter_index INTEGER NOT NULL,
            title TEXT NOT NULL,
            start_byte_offset INTEGER NOT NULL,
            end_byte_offset INTEGER NOT NULL,
            word_count INTEGER NOT NULL DEFAULT 0,
            UNIQUE(book_id, chapter_index),
            FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE
          )
        ''');

        await db.execute('''
          CREATE TABLE reading_progresses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL UNIQUE,
            chapter_id INTEGER NOT NULL,
            paragraph_index INTEGER NOT NULL DEFAULT 0,
            scroll_offset REAL NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL,
            FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE,
            FOREIGN KEY(chapter_id) REFERENCES chapters(id) ON DELETE CASCADE
          )
        ''');

        await db.execute('''
          CREATE TABLE app_settings (
            id INTEGER PRIMARY KEY CHECK(id = 1),
            theme_mode INTEGER NOT NULL DEFAULT 0,
            font_family TEXT NOT NULL DEFAULT 'sans-serif',
            animation_intensity REAL NOT NULL DEFAULT 1,
            enable_high_refresh INTEGER NOT NULL DEFAULT 1,
            enable_vibration INTEGER NOT NULL DEFAULT 1
          )
        ''');
      },
    );
    final database = LocalDatabase._(db);
    await database._emitBooks();
    return database;
  }

  Stream<List<BookModel>> watchBooks() {
    Future.microtask(_emitBooks);
    return _booksController.stream;
  }

  Future<List<BookModel>> getAllBooks() async {
    final rows = await _db.query('books', orderBy: 'import_time DESC');
    return rows.map(BookModel.fromMap).toList();
  }

  Future<void> _emitBooks() async {
    if (_booksController.isClosed) return;
    _booksController.add(await getAllBooks());
  }

  Future<int> insertImportResult(ImportResult result) async {
    final existing = await _db.query(
      'books',
      where: 'file_name_hash = ?',
      whereArgs: [result.fileHash],
      limit: 1,
    );
    if (existing.isNotEmpty) {
      final id = existing.first['id'] as int;
      await _emitBooks();
      return id;
    }

    final now = DateTime.now().millisecondsSinceEpoch;
    final bookId = await _db.transaction<int>((txn) async {
      final id = await txn.insert('books', {
        'title': result.title,
        'file_path': result.filePath,
        'file_name_hash': result.fileHash,
        'encoding': result.encoding,
        'import_time': now,
        'last_read_time': null,
      });

      int? firstChapterId;
      for (final chapter in result.chapters) {
        final chapterId = await txn.insert('chapters', {
          'book_id': id,
          'chapter_index': chapter.index,
          'title': chapter.title,
          'start_byte_offset': chapter.startByteOffset,
          'end_byte_offset': chapter.endByteOffset,
          'word_count': chapter.wordCount,
        });
        firstChapterId ??= chapterId;
      }

      if (firstChapterId != null) {
        await txn.insert('reading_progresses', {
          'book_id': id,
          'chapter_id': firstChapterId,
          'paragraph_index': 0,
          'scroll_offset': 0.0,
          'updated_at': now,
        });
      }
      return id;
    });

    await _emitBooks();
    return bookId;
  }

  Future<void> updateProgress({required int bookId, required int chapterId, required int paragraphIndex, required double scrollOffset}) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    await _db.insert(
      'reading_progresses',
      {
        'book_id': bookId,
        'chapter_id': chapterId,
        'paragraph_index': paragraphIndex,
        'scroll_offset': scrollOffset,
        'updated_at': now,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    await _db.update('books', {'last_read_time': now}, where: 'id = ?', whereArgs: [bookId]);
    await _emitBooks();
  }

  Future<void> deleteBook(int id) async {
    await _db.delete('books', where: 'id = ?', whereArgs: [id]);
    await _emitBooks();
  }

  Future<void> close() async {
    await _booksController.close();
    await _db.close();
  }
}

// =============================================================
// App root
// =============================================================
class TextOSApp extends StatefulWidget {
  final SharedPreferences prefs;
  final LocalDatabase database;

  const TextOSApp({super.key, required this.prefs, required this.database});

  @override
  State<TextOSApp> createState() => _TextOSAppState();
}

class _TextOSAppState extends State<TextOSApp> {
  late final ValueNotifier<ThemeMode> _themeNotifier;

  @override
  void initState() {
    super.initState();
    _themeNotifier = ValueNotifier(themeModeFromInt(widget.prefs.getInt('theme_mode') ?? 2));
  }

  Future<void> _setThemeMode(ThemeMode mode) async {
    _themeNotifier.value = mode;
    await widget.prefs.setInt('theme_mode', themeModeToInt(mode));
  }

  @override
  Widget build(BuildContext context) {
    final hasSeenOnboarding = widget.prefs.getBool('has_seen_onboarding') ?? false;
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: _themeNotifier,
      builder: (context, mode, _) {
        return AppScope(
          prefs: widget.prefs,
          database: widget.database,
          themeMode: mode,
          setThemeMode: _setThemeMode,
          child: MaterialApp(
            title: 'XinWei',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.light,
            darkTheme: AppTheme.dark,
            themeMode: mode,
            home: hasSeenOnboarding ? const V4AppShell() : const ViewOnboarding(),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _themeNotifier.dispose();
    super.dispose();
  }
}

class AppScope extends InheritedWidget {
  final SharedPreferences prefs;
  final LocalDatabase database;
  final ThemeMode themeMode;
  final Future<void> Function(ThemeMode mode) setThemeMode;

  const AppScope({
    super.key,
    required this.prefs,
    required this.database,
    required this.themeMode,
    required this.setThemeMode,
    required super.child,
  });

  static AppScope of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope not found');
    return scope!;
  }

  @override
  bool updateShouldNotify(AppScope oldWidget) {
    return oldWidget.themeMode != themeMode || oldWidget.database != database;
  }
}

// =============================================================
// Onboarding
// =============================================================
class ViewOnboarding extends StatefulWidget {
  const ViewOnboarding({super.key});

  @override
  State<ViewOnboarding> createState() => _ViewOnboardingState();
}

class _ViewOnboardingState extends State<ViewOnboarding> {
  final PageController _controller = PageController();
  int _page = 0;

  Future<void> _finish() async {
    await AppScope.of(context).prefs.setBool('has_seen_onboarding', true);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const V4AppShell()));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      body: Stack(
        children: [
          PageView(
            controller: _controller,
            onPageChanged: (value) => setState(() => _page = value),
            children: const [
              _OnboardingPage(
                title: '文本即世界',
                desc: '导入一部本地小说，XinWei 会把章节，进度，角色和未来的世界线都收进一个清晰的文本系统。',
              ),
              _OnboardingPage(
                title: '正史与新纬度',
                desc: '你可以安静阅读原文，也可以从某个段落进入平行世界，或从开头创建角色重新抵达故事。',
              ),
              _OnboardingPage(
                title: '文本即私有领地',
                desc: '本地小说默认只在设备端运行，绝不上传。只有你主动接入 AI 并触发跃迁时，相关上下文碎片才会发送至你配置的节点。',
              ),
            ],
          ),
          Positioned(
            bottom: MediaQuery.of(context).padding.bottom + 36,
            left: 28,
            right: 28,
            child: _page == 2
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      GestureDetector(
                        onTap: _finish,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          decoration: BoxDecoration(
                            color: colors.onSurface,
                            borderRadius: BorderRadius.circular(28),
                          ),
                          child: Center(
                            child: Text('进入 XinWei', style: TextStyle(color: Theme.of(context).scaffoldBackgroundColor, fontWeight: FontWeight.w700)),
                          ),
                        ),
                      ),
                    ],
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(onPressed: _finish, child: Text('跳过', style: TextStyle(color: colors.onSurface.withOpacity(0.42)))),
                      GestureDetector(
                        onTap: () => _controller.nextPage(duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(shape: BoxShape.circle, color: colors.onSurface.withOpacity(0.10)),
                          child: Icon(Icons.arrow_forward_rounded, color: colors.onSurface, size: 20),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}

class _OnboardingPage extends StatelessWidget {
  final String title;
  final String desc;

  const _OnboardingPage({required this.title, required this.desc});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.all(40),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(width: 42, height: 4, decoration: BoxDecoration(color: colors.onSurface, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 24),
          Text(title, style: TextStyle(color: colors.onSurface, fontSize: 28, height: 1.15, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
          const SizedBox(height: 16),
          Text(desc, style: TextStyle(color: colors.onSurface.withOpacity(0.55), fontSize: 15.5, height: 1.75)),
        ],
      ),
    );
  }
}

// =============================================================
// Shell
// =============================================================
enum AppPage { home, reader, characters, settings }

class V4AppShell extends StatefulWidget {
  const V4AppShell({super.key});

  @override
  State<V4AppShell> createState() => _V4AppShellState();
}

class _V4AppShellState extends State<V4AppShell> with SingleTickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final ScrollController _scrollController = ScrollController();
  late final AnimationController _flashController;

  AppPage _currentPage = AppPage.home;
  BookModel? _activeBook;
  bool _showMirror = false;

  @override
  void initState() {
    super.initState();
    _flashController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
  }

  void _navigateTo(AppPage page) {
    setState(() {
      _currentPage = page;
      if (page != AppPage.reader) _showMirror = false;
    });
  }

  void _openBookHub(BookModel book) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) {
        return _BookHubSheet(
          book: book,
          onEnterReader: () {
            Navigator.pop(sheetContext);
            setState(() {
              _activeBook = book;
              _currentPage = AppPage.reader;
              _showMirror = false;
            });
          },
        );
      },
    );
  }

  Future<void> _triggerParallelWorld() async {
    if (_showMirror) return;
    _flashController.value = 1;
    await Future.delayed(const Duration(milliseconds: 30));
    if (!mounted) return;
    setState(() => _showMirror = true);
    _flashController.reverse();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_scrollController.hasClients) return;
      _scrollController.animateTo(_scrollController.position.maxScrollExtent, duration: const Duration(milliseconds: 800), curve: Curves.fastOutSlowIn);
    });
  }

  String get _title {
    switch (_currentPage) {
      case AppPage.home:
        return '书架';
      case AppPage.reader:
        return _activeBook?.title ?? '示例阅读';
      case AppPage.characters:
        return '角色档案';
      case AppPage.settings:
        return '系统偏好';
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      key: _scaffoldKey,
      extendBodyBehindAppBar: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      drawer: V4Drawer(
        currentPage: _currentPage,
        onNavigate: (page) {
          Navigator.pop(context);
          _navigateTo(page);
        },
      ),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight),
        child: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
            child: AppBar(
              backgroundColor: Theme.of(context).scaffoldBackgroundColor.withOpacity(0.72),
              elevation: 0,
              scrolledUnderElevation: 0,
              leading: IconButton(
                icon: Icon(Icons.align_horizontal_left_rounded, color: colors.onSurface.withOpacity(0.45), size: 20),
                onPressed: () => _scaffoldKey.currentState?.openDrawer(),
              ),
              centerTitle: true,
              title: Text(_title, style: TextStyle(color: colors.onSurface.withOpacity(0.55), fontSize: 13, letterSpacing: 0.4)),
              actions: _currentPage == AppPage.reader
                  ? [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Text(_showMirror ? '镜像' : '正史', style: TextStyle(color: colors.onSurface.withOpacity(0.35), fontSize: 11))))]
                  : null,
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          _buildPage(),
          if (_currentPage == AppPage.reader)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Padding(
                padding: EdgeInsets.fromLTRB(18, 0, 18, MediaQuery.of(context).padding.bottom + 16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedOpacity(
                      opacity: !_showMirror ? 1 : 0,
                      duration: const Duration(milliseconds: 450),
                      child: IgnorePointer(
                        ignoring: _showMirror,
                        child: _FloatingChip(onTap: _triggerParallelWorld, label: '开启平行世界'),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const V4InputConsole(),
                  ],
                ),
              ),
            ),
          IgnorePointer(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _flashController, curve: Curves.easeOutCubic),
              child: Container(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPage() {
    switch (_currentPage) {
      case AppPage.home:
        return ViewHome(onOpenBook: _openBookHub);
      case AppPage.reader:
        return ViewReader(scrollController: _scrollController, showMirror: _showMirror, book: _activeBook);
      case AppPage.characters:
        return const ViewCharacters();
      case AppPage.settings:
        return ViewSettings(onOpenSetting: (title) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SettingDetailPage(title: title))));
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _flashController.dispose();
    super.dispose();
  }
}

// =============================================================
// Home with real persisted SQLite stream
// =============================================================
class ViewHome extends StatelessWidget {
  final void Function(BookModel book) onOpenBook;

  const ViewHome({super.key, required this.onOpenBook});

  Future<void> _addTestBook(BuildContext context) async {
    final db = AppScope.of(context).database;
    final stamp = DateTime.now().millisecondsSinceEpoch;
    final result = ImportResult(
      title: '测试书 $stamp',
      filePath: '/app/books/mock_$stamp.txt',
      fileHash: 'hash_$stamp',
      encoding: 'utf8',
      chapters: const [
        ChapterDraft(index: 0, title: '序章：风起', startByteOffset: 0, endByteOffset: 2048, wordCount: 680),
        ChapterDraft(index: 1, title: '第一章：新纬度', startByteOffset: 2049, endByteOffset: 8192, wordCount: 2100),
      ],
    );
    await db.insertImportResult(result);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('测试书已写入本地数据库，重启后仍会保留')));
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final db = AppScope.of(context).database;
    return StreamBuilder<List<BookModel>>(
      stream: db.watchBooks(),
      builder: (context, snapshot) {
        final books = snapshot.data ?? const <BookModel>[];
        return ListView(
          padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 24, bottom: 48, left: 20, right: 20),
          children: [
            GestureDetector(
              onTap: () => _addTestBook(context),
              child: Container(
                margin: const EdgeInsets.only(bottom: 20),
                padding: const EdgeInsets.symmetric(vertical: 22),
                decoration: BoxDecoration(
                  color: colors.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: colors.outline),
                ),
                child: Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.add_rounded, color: colors.onSurface.withOpacity(0.45), size: 18),
                      const SizedBox(width: 8),
                      Text('添加测试书，验证持久化', style: TextStyle(color: colors.onSurface.withOpacity(0.55), fontSize: 13)),
                    ],
                  ),
                ),
              ),
            ),
            if (books.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 44),
                child: Text('书架空空如也\n先添加一本测试书，杀进程重开验证数据库', textAlign: TextAlign.center, style: TextStyle(color: colors.onSurface.withOpacity(0.32), height: 1.7)),
              ),
            ...books.map((book) => _BookShelfCard(book: book, onTap: () => onOpenBook(book))),
          ],
        );
      },
    );
  }
}

class _BookShelfCard extends StatelessWidget {
  final BookModel book;
  final VoidCallback onTap;

  const _BookShelfCard({required this.book, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: colors.outline),
          boxShadow: _softShadow(context),
        ),
        child: Row(
          children: [
            Container(
              width: 58,
              height: 78,
              decoration: BoxDecoration(color: colors.onSurface.withOpacity(0.055), borderRadius: BorderRadius.circular(12), border: Border.all(color: colors.outline)),
              child: Icon(Icons.menu_book_rounded, color: colors.onSurface.withOpacity(0.23)),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(book.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: colors.onSurface, fontSize: 16, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 7),
                  Text('SQLite 持久化 · ${_formatTime(book.importTime)} 导入', style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 11.5)),
                  const SizedBox(height: 10),
                  Container(
                    height: 4,
                    decoration: BoxDecoration(color: colors.onSurface.withOpacity(0.08), borderRadius: BorderRadius.circular(99)),
                    alignment: Alignment.centerLeft,
                    child: FractionallySizedBox(
                      widthFactor: 0.12,
                      child: Container(decoration: BoxDecoration(color: colors.onSurface.withOpacity(0.55), borderRadius: BorderRadius.circular(99))),
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: colors.onSurface.withOpacity(0.25)),
          ],
        ),
      ),
    );
  }
}

// =============================================================
// Reader
// =============================================================
class ViewReader extends StatelessWidget {
  final ScrollController scrollController;
  final bool showMirror;
  final BookModel? book;

  const ViewReader({super.key, required this.scrollController, required this.showMirror, required this.book});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return ListView(
      controller: scrollController,
      padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 24, bottom: 190, left: 20, right: 20),
      children: [
        _SystemLine(text: book == null ? '示例文本已载入' : '已载入：${book!.title}'),
        const SizedBox(height: 22),
        _TextCard(
          title: '正史阅读',
          content: '那晚弘大街头的风很凉，他突然在人群中转过身。这里陷入了长久的沉默。',
          accent: colors.onSurface.withOpacity(0.20),
        ),
        if (showMirror) ...[
          const SizedBox(height: 26),
          const _SystemLine(text: '世界线已偏移'),
          const SizedBox(height: 20),
          _TextCard(
            title: '镜像世界 001',
            content: '世界线已偏移。他低下头，孤身走向那场没有终点的暴雨。你在街角醒来，第一次意识到，自己并不是这个故事的旁观者。',
            accent: colors.onSurface.withOpacity(0.45),
            isMirror: true,
          ),
        ],
      ],
    );
  }
}

class _TextCard extends StatelessWidget {
  final String title;
  final String content;
  final Color accent;
  final bool isMirror;

  const _TextCard({required this.title, required this.content, required this.accent, this.isMirror = false});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: isMirror ? colors.surfaceContainerHighest.withOpacity(0.82) : colors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isMirror ? accent : colors.outline),
        boxShadow: _softShadow(context),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(color: colors.onSurface.withOpacity(0.45), fontSize: 11, letterSpacing: 1.2)),
          const SizedBox(height: 13),
          Text(content, style: TextStyle(color: colors.onSurface.withOpacity(0.88), fontSize: 16.5, height: 1.78, fontFamily: 'serif')),
        ],
      ),
    );
  }
}

class _SystemLine extends StatelessWidget {
  final String text;
  const _SystemLine({required this.text});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Center(child: Text('—— $text ——', style: TextStyle(color: colors.onSurface.withOpacity(0.24), fontSize: 10, letterSpacing: 1.4)));
  }
}

class _FloatingChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _FloatingChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: colors.surfaceContainerHighest.withOpacity(0.8),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: colors.outline),
          boxShadow: _softShadow(context),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.auto_awesome_rounded, color: colors.onSurface.withOpacity(0.65), size: 13),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(color: colors.onSurface.withOpacity(0.68), fontSize: 12, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class V4InputConsole extends StatelessWidget {
  const V4InputConsole({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: colors.outline),
        boxShadow: _softShadow(context),
      ),
      child: Row(
        children: [
          Icon(Icons.keyboard_command_key_rounded, size: 17, color: colors.onSurface.withOpacity(0.32)),
          const SizedBox(width: 10),
          Expanded(child: Text('输入行动，或等待下一段文本...', style: TextStyle(color: colors.onSurface.withOpacity(0.35), fontSize: 13))),
          Icon(Icons.arrow_upward_rounded, size: 18, color: colors.onSurface.withOpacity(0.42)),
        ],
      ),
    );
  }
}

// =============================================================
// Characters and settings
// =============================================================
class ViewCharacters extends StatelessWidget {
  const ViewCharacters({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return ListView(
      padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 24, left: 20, right: 20),
      children: [
        _PanelCard(icon: Icons.person_add_alt_1_rounded, title: '创建默认角色', subtitle: '为从头重生模式准备身份，性格，阵营和能力。', onTap: () {}),
        _PanelCard(icon: Icons.badge_outlined, title: '李欣蔚，观测者', subtitle: '示例档案 · 暂未绑定任何世界线。', onTap: () {}),
      ],
    );
  }
}

class ViewSettings extends StatelessWidget {
  final void Function(String title) onOpenSetting;
  const ViewSettings({super.key, required this.onOpenSetting});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 24, left: 20, right: 20),
      children: [
        _PanelCard(icon: Icons.palette_outlined, title: '外观与主题', subtitle: '跟随系统，浅色，深色。', onTap: () => onOpenSetting('外观与主题')),
        _PanelCard(icon: Icons.text_fields_rounded, title: '阅读与排版', subtitle: '字体，字号，行距，段落间距。', onTap: () => onOpenSetting('阅读与排版')),
        _PanelCard(icon: Icons.vibration_rounded, title: '动画与马达', subtitle: '动画强度，高刷模式，触觉反馈。', onTap: () => onOpenSetting('动画与马达')),
        _PanelCard(icon: Icons.api_rounded, title: '大模型 API 接入', subtitle: '提供商，模型，Endpoint，超时与重试。', onTap: () => onOpenSetting('大模型 API 接入')),
        _PanelCard(icon: Icons.timeline_rounded, title: '平行世界规则', subtitle: '正史忠诚度，自由度，选项数量。', onTap: () => onOpenSetting('平行世界规则')),
        _PanelCard(icon: Icons.lock_outline_rounded, title: '数据与隐私', subtitle: '导出存档，清理缓存，请求记录。', onTap: () => onOpenSetting('数据与隐私')),
      ],
    );
  }
}

class SettingDetailPage extends StatelessWidget {
  final String title;
  const SettingDetailPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final scope = AppScope.of(context);
    final isAppearance = title == '外观与主题';
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        title: Text(title, style: TextStyle(color: colors.onSurface.withOpacity(0.72), fontSize: 14)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (isAppearance) ...[
            _ThemeChoice(label: '跟随系统', mode: ThemeMode.system, current: scope.themeMode),
            _ThemeChoice(label: '白天模式', mode: ThemeMode.light, current: scope.themeMode),
            _ThemeChoice(label: '黑夜模式', mode: ThemeMode.dark, current: scope.themeMode),
          ] else ...[
            _PanelCard(icon: Icons.construction_rounded, title: '$title 选项占位', subtitle: '功能入口已建立，后续版本接入真实逻辑。', onTap: () {}),
          ],
        ],
      ),
    );
  }
}

class _ThemeChoice extends StatelessWidget {
  final String label;
  final ThemeMode mode;
  final ThemeMode current;

  const _ThemeChoice({required this.label, required this.mode, required this.current});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final selected = mode == current;
    return GestureDetector(
      onTap: () => AppScope.of(context).setThemeMode(mode),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: selected ? colors.surfaceContainerHighest : colors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? colors.onSurface.withOpacity(0.35) : colors.outline),
        ),
        child: Row(
          children: [
            Expanded(child: Text(label, style: TextStyle(color: colors.onSurface, fontSize: 14, fontWeight: FontWeight.w600))),
            if (selected) Icon(Icons.check_rounded, color: colors.onSurface.withOpacity(0.72)),
          ],
        ),
      ),
    );
  }
}

class _PanelCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _PanelCard({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: colors.outline), boxShadow: _softShadow(context)),
        child: Row(
          children: [
            Icon(icon, color: colors.onSurface.withOpacity(0.55), size: 22),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(color: colors.onSurface, fontSize: 14.5, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(subtitle, style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 12, height: 1.35)),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: colors.onSurface.withOpacity(0.22)),
          ],
        ),
      ),
    );
  }
}

// =============================================================
// Drawer and book hub
// =============================================================
class V4Drawer extends StatelessWidget {
  final AppPage currentPage;
  final void Function(AppPage page) onNavigate;

  const V4Drawer({super.key, required this.currentPage, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Drawer(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 26, 24, 16),
              child: Text('XINWEI', style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 2.4)),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                children: [
                  _DrawerItem(icon: Icons.menu_book_rounded, label: '书架', active: currentPage == AppPage.home, onTap: () => onNavigate(AppPage.home)),
                  _DrawerItem(icon: Icons.auto_stories_outlined, label: '阅读流', active: currentPage == AppPage.reader, onTap: () => onNavigate(AppPage.reader)),
                  _DrawerItem(icon: Icons.person_outline_rounded, label: '角色档案', active: currentPage == AppPage.characters, onTap: () => onNavigate(AppPage.characters)),
                  _DrawerItem(icon: Icons.tune_rounded, label: '设置', active: currentPage == AppPage.settings, onTap: () => onNavigate(AppPage.settings)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: colors.outline)),
                child: Row(
                  children: [
                    CircleAvatar(radius: 16, backgroundColor: colors.onSurface.withOpacity(0.10), child: Icon(Icons.person_rounded, size: 18, color: colors.onSurface.withOpacity(0.45))),
                    const SizedBox(width: 10),
                    Expanded(child: Text('游客模式', style: TextStyle(color: colors.onSurface.withOpacity(0.62), fontSize: 13))),
                    GestureDetector(
                      onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('云同步登录功能开发中'))),
                      child: Text('登录', style: TextStyle(color: colors.onSurface.withOpacity(0.38), fontSize: 12)),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _DrawerItem({required this.icon, required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return ListTile(
      dense: true,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      tileColor: active ? colors.surfaceContainerHighest : Colors.transparent,
      leading: Icon(icon, color: colors.onSurface.withOpacity(active ? 0.70 : 0.30), size: 19),
      title: Text(label, style: TextStyle(color: colors.onSurface.withOpacity(active ? 0.76 : 0.42), fontSize: 13)),
      onTap: onTap,
    );
  }
}

class _BookHubSheet extends StatelessWidget {
  final BookModel book;
  final VoidCallback onEnterReader;

  const _BookHubSheet({required this.book, required this.onEnterReader});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(book.title, style: TextStyle(color: colors.onSurface, fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text('本地数据库记录 · 2 个测试章节 · 游客可用', style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 12)),
            const SizedBox(height: 22),
            _SheetAction(icon: Icons.play_arrow_rounded, title: '继续阅读正史', subtitle: '从上次位置继续进入信息流。', onTap: onEnterReader),
            _SheetAction(icon: Icons.person_add_alt_1_rounded, title: '从头创建角色', subtitle: 'V5 接入角色档案与重生模式。', onTap: () {}),
            _SheetAction(icon: Icons.timeline_rounded, title: '查看世界线', subtitle: 'V5 接入镜像节点与分支存档。', onTap: () {}),
          ],
        ),
      ),
    );
  }
}

class _SheetAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _SheetAction({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: colors.surfaceContainerHighest.withOpacity(0.78), borderRadius: BorderRadius.circular(16), border: Border.all(color: colors.outline)),
        child: Row(
          children: [
            Icon(icon, color: colors.onSurface.withOpacity(0.64), size: 23),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(color: colors.onSurface, fontSize: 14, fontWeight: FontWeight.w700)),
                const SizedBox(height: 3),
                Text(subtitle, style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 11.5)),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

// =============================================================
// Helpers
// =============================================================
List<BoxShadow> _softShadow(BuildContext context) {
  final dark = Theme.of(context).brightness == Brightness.dark;
  return [
    BoxShadow(
      color: Colors.black.withOpacity(dark ? 0.55 : 0.07),
      blurRadius: dark ? 22 : 18,
      offset: const Offset(0, 8),
    ),
  ];
}

String _formatTime(int millis) {
  final dt = DateTime.fromMillisecondsSinceEpoch(millis);
  String two(int v) => v.toString().padLeft(2, '0');
  return '${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}';
}
