import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarDividerColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  final controller = await XinWeiController.create();
  runApp(XinWeiApp(controller: controller));
}

class XinWeiBook {
  final String id;
  final String title;
  final String subtitle;
  final double progress;
  final int worldlines;
  final DateTime updatedAt;

  const XinWeiBook({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.progress,
    required this.worldlines,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'subtitle': subtitle,
        'progress': progress,
        'worldlines': worldlines,
        'updatedAt': updatedAt.toIso8601String(),
      };

  static XinWeiBook fromJson(Map<String, dynamic> json) => XinWeiBook(
        id: json['id'] as String,
        title: json['title'] as String,
        subtitle: json['subtitle'] as String? ?? '本地文本',
        progress: (json['progress'] as num?)?.toDouble() ?? 0,
        worldlines: json['worldlines'] as int? ?? 0,
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ?? DateTime.now(),
      );
}

class XinWeiController extends ChangeNotifier {
  final SharedPreferences prefs;
  bool hasSeenOnboarding;
  ThemeMode themeMode;
  final List<XinWeiBook> books;

  XinWeiController._({
    required this.prefs,
    required this.hasSeenOnboarding,
    required this.themeMode,
    required this.books,
  });

  static Future<XinWeiController> create() async {
    final prefs = await SharedPreferences.getInstance();
    final themeIndex = prefs.getInt('theme_mode') ?? 2;
    final rawBooks = prefs.getStringList('books') ?? [];
    final books = rawBooks
        .map((e) {
          try {
            return XinWeiBook.fromJson(jsonDecode(e) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<XinWeiBook>()
        .toList();

    if (books.isEmpty) {
      books.add(
        XinWeiBook(
          id: 'demo_hongdae',
          title: '弘大街头',
          subtitle: '示例文本 · 正史阅读',
          progress: 0.12,
          worldlines: 2,
          updatedAt: DateTime.now(),
        ),
      );
    }

    return XinWeiController._(
      prefs: prefs,
      hasSeenOnboarding: prefs.getBool('has_seen_onboarding') ?? false,
      themeMode: ThemeMode.values[themeIndex.clamp(0, 2)],
      books: books,
    );
  }

  Future<void> finishOnboarding() async {
    hasSeenOnboarding = true;
    await prefs.setBool('has_seen_onboarding', true);
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode = mode;
    await prefs.setInt('theme_mode', mode.index);
    _syncSystemBars();
    notifyListeners();
  }

  Future<void> addTestBook() async {
    final now = DateTime.now();
    books.insert(
      0,
      XinWeiBook(
        id: 'test_${now.millisecondsSinceEpoch}',
        title: '测试书 ${books.length + 1}',
        subtitle: '本地持久化验证',
        progress: 0,
        worldlines: 0,
        updatedAt: now,
      ),
    );
    await _saveBooks();
    notifyListeners();
  }

  Future<void> _saveBooks() async {
    await prefs.setStringList('books', books.map((b) => jsonEncode(b.toJson())).toList());
  }

  void _syncSystemBars() {
    final dark = themeMode == ThemeMode.dark;
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarDividerColor: Colors.transparent,
        statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
        systemNavigationBarIconBrightness: dark ? Brightness.light : Brightness.dark,
      ),
    );
  }
}

class AppColors {
  static const darkBg = Color(0xFF000000);
  static const darkSurface = Color(0xFF0A0A0A);
  static const darkElevated = Color(0xFF141414);
  static const darkBorder = Color(0xFF1C1C1C);
  static const darkMain = Color(0xFFE8E8E8);
  static const darkSub = Color(0xFF777777);

  static const lightBg = Color(0xFFF7F7F4);
  static const lightSurface = Color(0xFFFFFFFF);
  static const lightElevated = Color(0xFFF0F0EE);
  static const lightBorder = Color(0xFFE0E0DC);
  static const lightMain = Color(0xFF1E1E1D);
  static const lightSub = Color(0xFF777772);
}

class XinWeiTheme {
  static ThemeData get dark => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.darkBg,
        fontFamily: 'sans-serif',
        colorScheme: const ColorScheme.dark(
          surface: AppColors.darkSurface,
          surfaceContainerHighest: AppColors.darkElevated,
          onSurface: AppColors.darkMain,
          outline: AppColors.darkBorder,
          secondary: AppColors.darkSub,
        ),
      );

  static ThemeData get light => ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: AppColors.lightBg,
        fontFamily: 'sans-serif',
        colorScheme: const ColorScheme.light(
          surface: AppColors.lightSurface,
          surfaceContainerHighest: AppColors.lightElevated,
          onSurface: AppColors.lightMain,
          outline: AppColors.lightBorder,
          secondary: AppColors.lightSub,
        ),
      );
}

class XinWeiApp extends StatelessWidget {
  final XinWeiController controller;
  const XinWeiApp({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'XinWei',
          theme: XinWeiTheme.light,
          darkTheme: XinWeiTheme.dark,
          themeMode: controller.themeMode,
          home: controller.hasSeenOnboarding
              ? V4Shell(controller: controller)
              : OnboardingView(controller: controller),
        );
      },
    );
  }
}

class OnboardingView extends StatefulWidget {
  final XinWeiController controller;
  const OnboardingView({super.key, required this.controller});

  @override
  State<OnboardingView> createState() => _OnboardingViewState();
}

class _OnboardingViewState extends State<OnboardingView> {
  final PageController _pageController = PageController();
  int _page = 0;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      extendBody: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Stack(
        children: [
          PageView(
            controller: _pageController,
            onPageChanged: (value) => setState(() => _page = value),
            children: const [
              OnboardingPage(
                title: '文本即世界',
                body: '导入一部本地小说，XinWei 会把静态文本整理成清晰的信息流。',
              ),
              OnboardingPage(
                title: '正史与平行',
                body: '你可以安静阅读原文，也可以从某个段落创建镜像世界线。',
              ),
              OnboardingPage(
                title: '文本即私有领地',
                body: '本地小说默认不上传。只有你主动启用 AI 跃迁时，相关上下文才会发送到你配置的节点。',
              ),
            ],
          ),
          Positioned(
            left: 28,
            right: 28,
            bottom: MediaQuery.of(context).padding.bottom + 34,
            child: _page == 2
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      PrimaryCapsuleButton(
                        label: '先体验示例世界',
                        onTap: widget.controller.finishOnboarding,
                      ),
                      const SizedBox(height: 14),
                      Text(
                        '或稍后导入本地文本',
                        style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 13),
                      ),
                    ],
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                        onPressed: widget.controller.finishOnboarding,
                        child: Text('跳过', style: TextStyle(color: colors.onSurface.withOpacity(0.44))),
                      ),
                      GestureDetector(
                        onTap: () => _pageController.nextPage(
                          duration: const Duration(milliseconds: 320),
                          curve: Curves.easeOutCubic,
                        ),
                        child: Container(
                          padding: const EdgeInsets.all(13),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: colors.onSurface.withOpacity(0.10),
                          ),
                          child: Icon(Icons.arrow_forward_rounded, color: colors.onSurface, size: 21),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}

class OnboardingPage extends StatelessWidget {
  final String title;
  final String body;
  const OnboardingPage({super.key, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 38),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 42,
            height: 4,
            decoration: BoxDecoration(color: colors.onSurface, borderRadius: BorderRadius.circular(99)),
          ),
          const SizedBox(height: 24),
          Text(title, style: TextStyle(color: colors.onSurface, fontSize: 29, fontWeight: FontWeight.w800, height: 1.15)),
          const SizedBox(height: 16),
          Text(body, style: TextStyle(color: colors.onSurface.withOpacity(0.54), fontSize: 15.5, height: 1.75)),
        ],
      ),
    );
  }
}

enum AppPage { home, reader, characters, settings }

class V4Shell extends StatefulWidget {
  final XinWeiController controller;
  const V4Shell({super.key, required this.controller});

  @override
  State<V4Shell> createState() => _V4ShellState();
}

class _V4ShellState extends State<V4Shell> with SingleTickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final ScrollController _readerScroll = ScrollController();
  late final AnimationController _flashController;
  AppPage _page = AppPage.home;
  bool _showMirror = false;

  @override
  void initState() {
    super.initState();
    _flashController = AnimationController(vsync: this, duration: const Duration(milliseconds: 760));
  }

  @override
  void dispose() {
    _readerScroll.dispose();
    _flashController.dispose();
    super.dispose();
  }

  void _navigate(AppPage page) {
    setState(() {
      _page = page;
      if (page != AppPage.reader) _showMirror = false;
    });
  }

  void _openBookHub(XinWeiBook book) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      barrierColor: Colors.black.withOpacity(0.48),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) {
        return BookHubSheet(
          book: book,
          onRead: () {
            Navigator.pop(sheetContext);
            _navigate(AppPage.reader);
          },
        );
      },
    );
  }

  Future<void> _enterMirror() async {
    if (_showMirror) return;
    _flashController.value = 1;
    await Future<void>.delayed(const Duration(milliseconds: 30));
    if (!mounted) return;
    setState(() => _showMirror = true);
    _flashController.reverse();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_readerScroll.hasClients) return;
      _readerScroll.animateTo(
        _readerScroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 760),
        curve: Curves.easeOutCubic,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      key: _scaffoldKey,
      extendBody: true,
      extendBodyBehindAppBar: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      drawer: XinWeiDrawer(
        controller: widget.controller,
        current: _page,
        onNavigate: (page) {
          Navigator.pop(context);
          _navigate(page);
        },
      ),
      appBar: _buildAppBar(colors),
      body: Stack(
        children: [
          _buildPage(),
          if (_page == AppPage.reader)
            Positioned(
              left: 18,
              right: 18,
              bottom: MediaQuery.of(context).padding.bottom + 16,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedOpacity(
                    opacity: _showMirror ? 0 : 1,
                    duration: const Duration(milliseconds: 420),
                    child: IgnorePointer(
                      ignoring: _showMirror,
                      child: GestureDetector(
                        onTap: _enterMirror,
                        child: FloatingChip(label: '开启平行世界', icon: Icons.auto_awesome_rounded),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const InputConsole(),
                ],
              ),
            ),
          IgnorePointer(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _flashController, curve: Curves.easeOutCubic),
              child: Container(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(ColorScheme colors) {
    final title = switch (_page) {
      AppPage.home => '书架',
      AppPage.reader => '弘大街头.txt',
      AppPage.characters => '角色档案',
      AppPage.settings => '系统偏好',
    };

    return PreferredSize(
      preferredSize: const Size.fromHeight(kToolbarHeight),
      child: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: AppBar(
            backgroundColor: Theme.of(context).scaffoldBackgroundColor.withOpacity(0.62),
            elevation: 0,
            scrolledUnderElevation: 0,
            leading: IconButton(
              onPressed: () => _scaffoldKey.currentState?.openDrawer(),
              icon: Icon(Icons.menu_rounded, size: 21, color: colors.onSurface.withOpacity(0.56)),
            ),
            centerTitle: true,
            title: Text(title, style: TextStyle(color: colors.onSurface.withOpacity(0.58), fontSize: 13, letterSpacing: 0.4)),
            actions: _page == AppPage.reader
                ? [
                    Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: Center(child: Text(_showMirror ? '镜像' : '正史', style: TextStyle(color: colors.onSurface.withOpacity(0.35), fontSize: 11))),
                    ),
                  ]
                : null,
          ),
        ),
      ),
    );
  }

  Widget _buildPage() {
    return switch (_page) {
      AppPage.home => HomeView(controller: widget.controller, onOpenBook: _openBookHub),
      AppPage.reader => ReaderView(controller: _readerScroll, showMirror: _showMirror),
      AppPage.characters => const CharactersView(),
      AppPage.settings => SettingsView(controller: widget.controller),
    };
  }
}

class HomeView extends StatelessWidget {
  final XinWeiController controller;
  final ValueChanged<XinWeiBook> onOpenBook;
  const HomeView({super.key, required this.controller, required this.onOpenBook});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return ListView(
          padding: EdgeInsets.only(
            top: kToolbarHeight + MediaQuery.of(context).padding.top + 24,
            left: 20,
            right: 20,
            bottom: MediaQuery.of(context).padding.bottom + 32,
          ),
          children: [
            GestureDetector(
              onTap: controller.addTestBook,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 18),
                margin: const EdgeInsets.only(bottom: 22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: colors.outline),
                  color: colors.surface.withOpacity(0.62),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.add_rounded, color: colors.onSurface.withOpacity(0.48), size: 18),
                    const SizedBox(width: 8),
                    Text('添加测试书', style: TextStyle(color: colors.onSurface.withOpacity(0.48), fontSize: 13)),
                  ],
                ),
              ),
            ),
            ...controller.books.map((book) => BookCard(book: book, onTap: () => onOpenBook(book))),
          ],
        );
      },
    );
  }
}

class BookCard extends StatelessWidget {
  final XinWeiBook book;
  final VoidCallback onTap;
  const BookCard({super.key, required this.book, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: colors.outline),
          boxShadow: [softShadow(context)],
        ),
        child: Row(
          children: [
            Container(
              width: 64,
              height: 86,
              decoration: BoxDecoration(
                color: colors.onSurface.withOpacity(0.045),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: colors.outline.withOpacity(0.5)),
              ),
              child: Icon(Icons.menu_book_rounded, color: colors.onSurface.withOpacity(0.24), size: 26),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(book.title, style: TextStyle(color: colors.onSurface, fontSize: 17, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 5),
                  Text(book.subtitle, style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 12)),
                  const SizedBox(height: 14),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(
                      minHeight: 4,
                      value: book.progress,
                      backgroundColor: colors.onSurface.withOpacity(0.08),
                      valueColor: AlwaysStoppedAnimation(colors.onSurface.withOpacity(0.58)),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('进度 ${(book.progress * 100).round()}% · ${book.worldlines} 条世界线', style: TextStyle(color: colors.onSurface.withOpacity(0.34), fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ReaderView extends StatelessWidget {
  final ScrollController controller;
  final bool showMirror;
  const ReaderView({super.key, required this.controller, required this.showMirror});

  @override
  Widget build(BuildContext context) {
    return ListView(
      controller: controller,
      padding: EdgeInsets.only(
        top: kToolbarHeight + MediaQuery.of(context).padding.top + 28,
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).padding.bottom + 190,
      ),
      children: [
        const SystemLine('场景已转换：弘大街头'),
        const SizedBox(height: 22),
        const CanonCard('那晚弘大街头的风很凉，他突然在人群中转过身。这里陷入了长久的沉默。'),
        if (showMirror) ...const [
          SizedBox(height: 26),
          SystemLine('世界线已偏移'),
          SizedBox(height: 22),
          MirrorCard('世界线已偏移。他低下头，孤身走向了那场没有终点的暴雨。'),
        ],
      ],
    );
  }
}

class CanonCard extends StatelessWidget {
  final String text;
  const CanonCard(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colors.outline.withOpacity(0.8)),
      ),
      child: Text(text, style: TextStyle(color: colors.onSurface.withOpacity(0.9), fontSize: 16.5, height: 1.85, letterSpacing: 0.2, fontFamily: 'serif')),
    );
  }
}

class MirrorCard extends StatelessWidget {
  final String text;
  const MirrorCard(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest.withOpacity(0.68),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: colors.onSurface.withOpacity(0.16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('MIRROR 001', style: TextStyle(color: colors.onSurface.withOpacity(0.34), fontSize: 10, letterSpacing: 1.4)),
          const SizedBox(height: 12),
          Text(text, style: TextStyle(color: colors.onSurface.withOpacity(0.88), fontSize: 16.2, height: 1.82, fontFamily: 'serif')),
        ],
      ),
    );
  }
}

class SystemLine extends StatelessWidget {
  final String text;
  const SystemLine(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Center(
      child: Text('—— $text ——', style: TextStyle(color: colors.onSurface.withOpacity(0.28), fontSize: 10.5, letterSpacing: 1.2)),
    );
  }
}

class CharactersView extends StatelessWidget {
  const CharactersView({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return ListView(
      padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 24, left: 20, right: 20, bottom: 32),
      children: [
        SectionTitle('角色档案'),
        const SizedBox(height: 12),
        InfoCard(
          icon: Icons.person_add_alt_1_rounded,
          title: '新建自定义角色',
          subtitle: '姓名，身份，阵营，能力，性格锚点。',
          onTap: () => showSoon(context),
        ),
        InfoCard(
          icon: Icons.visibility_rounded,
          title: '旁观者模板',
          subtitle: '不进入剧情，只作为世界线观察者。',
          onTap: () => showSoon(context),
        ),
        Container(
          margin: const EdgeInsets.only(top: 18),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: colors.outline)),
          child: Text('角色系统会在 V6 接入。现在先保留入口和交互层级。', style: TextStyle(color: colors.onSurface.withOpacity(0.45), fontSize: 13, height: 1.6)),
        ),
      ],
    );
  }
}

class SettingsView extends StatelessWidget {
  final XinWeiController controller;
  const SettingsView({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 24, left: 20, right: 20, bottom: 32),
      children: [
        SectionTitle('基础'),
        InfoCard(icon: Icons.contrast_rounded, title: '外观模式', subtitle: themeLabel(controller.themeMode), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ThemeSettingsPage(controller: controller)))),
        InfoCard(icon: Icons.text_fields_rounded, title: '阅读排版', subtitle: '字体大小，行距，卡片宽度。', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlaceholderSettingsPage(title: '阅读排版')))),
        SectionTitle('体验'),
        InfoCard(icon: Icons.animation_rounded, title: '动画与马达', subtitle: '动效强度，触觉反馈，低性能模式。', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlaceholderSettingsPage(title: '动画与马达')))),
        InfoCard(icon: Icons.auto_awesome_rounded, title: '平行世界规则', subtitle: '正史忠诚度，选项数量，自由度。', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlaceholderSettingsPage(title: '平行世界规则')))),
        SectionTitle('连接'),
        InfoCard(icon: Icons.api_rounded, title: '大模型 API', subtitle: '提供商，Key，自定义 Endpoint。', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlaceholderSettingsPage(title: '大模型 API')))),
        InfoCard(icon: Icons.privacy_tip_outlined, title: '数据与隐私', subtitle: '本地小说默认不上传。', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PlaceholderSettingsPage(title: '数据与隐私')))),
      ],
    );
  }
}

class ThemeSettingsPage extends StatelessWidget {
  final XinWeiController controller;
  const ThemeSettingsPage({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('外观模式', style: TextStyle(fontSize: 14)),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor.withOpacity(0.62),
        elevation: 0,
      ),
      body: AnimatedBuilder(
        animation: controller,
        builder: (context, _) {
          return ListView(
            padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 24, left: 20, right: 20),
            children: [
              RadioTile(label: '跟随系统', value: ThemeMode.system, group: controller.themeMode, onTap: controller.setThemeMode),
              RadioTile(label: '浅色模式', value: ThemeMode.light, group: controller.themeMode, onTap: controller.setThemeMode),
              RadioTile(label: '深色模式', value: ThemeMode.dark, group: controller.themeMode, onTap: controller.setThemeMode),
              const SizedBox(height: 18),
              Text('白天模式不是反色，而是一套独立的纸质灰白主题。', style: TextStyle(color: colors.onSurface.withOpacity(0.38), height: 1.6)),
            ],
          );
        },
      ),
    );
  }
}

class RadioTile extends StatelessWidget {
  final String label;
  final ThemeMode value;
  final ThemeMode group;
  final ValueChanged<ThemeMode> onTap;
  const RadioTile({super.key, required this.label, required this.value, required this.group, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final active = value == group;
    return GestureDetector(
      onTap: () => onTap(value),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: active ? colors.onSurface.withOpacity(0.32) : colors.outline)),
        child: Row(
          children: [
            Expanded(child: Text(label, style: TextStyle(color: colors.onSurface, fontSize: 14))),
            Icon(active ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, color: colors.onSurface.withOpacity(active ? 0.78 : 0.28), size: 20),
          ],
        ),
      ),
    );
  }
}

class PlaceholderSettingsPage extends StatelessWidget {
  final String title;
  const PlaceholderSettingsPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(title: Text(title, style: const TextStyle(fontSize: 14)), backgroundColor: Theme.of(context).scaffoldBackgroundColor.withOpacity(0.62), elevation: 0),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Text('$title 会在后续版本开放。现在先预留完整入口。', textAlign: TextAlign.center, style: TextStyle(color: colors.onSurface.withOpacity(0.45), height: 1.7)),
        ),
      ),
    );
  }
}

class XinWeiDrawer extends StatelessWidget {
  final XinWeiController controller;
  final AppPage current;
  final ValueChanged<AppPage> onNavigate;
  const XinWeiDrawer({super.key, required this.controller, required this.current, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Drawer(
      backgroundColor: colors.surface,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 26, 22, 14),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset('assets/icon.png', width: 32, height: 32),
                  ),
                  const SizedBox(width: 12),
                  Text('XinWei', style: TextStyle(color: colors.onSurface.withOpacity(0.72), fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 0.8)),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                children: [
                  drawerItem(context, Icons.library_books_rounded, '书架', AppPage.home),
                  drawerItem(context, Icons.route_rounded, '世界线', AppPage.reader),
                  drawerItem(context, Icons.person_outline_rounded, '角色档案', AppPage.characters),
                  drawerItem(context, Icons.tune_rounded, '设置', AppPage.settings),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: colors.surfaceContainerHighest.withOpacity(0.58), borderRadius: BorderRadius.circular(16), border: Border.all(color: colors.outline)),
                child: Row(
                  children: [
                    Icon(Icons.account_circle_outlined, color: colors.onSurface.withOpacity(0.42), size: 26),
                    const SizedBox(width: 10),
                    Expanded(child: Text('游客模式\n云同步登录入口预留', style: TextStyle(color: colors.onSurface.withOpacity(0.48), fontSize: 11, height: 1.4))),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget drawerItem(BuildContext context, IconData icon, String label, AppPage page) {
    final colors = Theme.of(context).colorScheme;
    final active = current == page;
    return ListTile(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      tileColor: active ? colors.surfaceContainerHighest.withOpacity(0.75) : Colors.transparent,
      leading: Icon(icon, color: colors.onSurface.withOpacity(active ? 0.72 : 0.28), size: 19),
      title: Text(label, style: TextStyle(color: colors.onSurface.withOpacity(active ? 0.72 : 0.38), fontSize: 13)),
      onTap: () => onNavigate(page),
      dense: true,
    );
  }
}

class BookHubSheet extends StatelessWidget {
  final XinWeiBook book;
  final VoidCallback onRead;
  const BookHubSheet({super.key, required this.book, required this.onRead});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(22, 22, 22, 26),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(book.title, style: TextStyle(color: colors.onSurface, fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text('${book.worldlines} 条世界线 · 阅读进度 ${(book.progress * 100).round()}%', style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 12)),
            const SizedBox(height: 22),
            ModeCard(icon: Icons.play_arrow_rounded, title: '继续观测正史', subtitle: '从上次离开的段落继续阅读', onTap: onRead),
            ModeCard(icon: Icons.person_add_alt_1_rounded, title: '从头创建角色', subtitle: '使用自建身份进入第一章', onTap: () => showSoon(context)),
            ModeCard(icon: Icons.explore_outlined, title: '自由沙盒', subtitle: '保留世界观，允许剧情大幅偏移', onTap: () => showSoon(context)),
          ],
        ),
      ),
    );
  }
}

class ModeCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const ModeCard({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: colors.surfaceContainerHighest.withOpacity(0.62), borderRadius: BorderRadius.circular(16), border: Border.all(color: colors.outline)),
        child: Row(
          children: [
            Icon(icon, color: colors.onSurface.withOpacity(0.72), size: 24),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(color: colors.onSurface, fontSize: 14, fontWeight: FontWeight.w650)),
                const SizedBox(height: 3),
                Text(subtitle, style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 11)),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

class InputConsole extends StatelessWidget {
  const InputConsole({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: colors.outline),
        boxShadow: [softShadow(context)],
      ),
      child: Row(
        children: [
          Icon(Icons.add_rounded, color: colors.onSurface.withOpacity(0.62), size: 24),
          const SizedBox(width: 12),
          Expanded(child: Text('向 XinWei 输入行动', style: TextStyle(color: colors.onSurface.withOpacity(0.35), fontSize: 14))),
          Icon(Icons.mic_none_rounded, color: colors.onSurface.withOpacity(0.38), size: 22),
          const SizedBox(width: 8),
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(shape: BoxShape.circle, color: colors.onSurface.withOpacity(0.12)),
            child: Icon(Icons.graphic_eq_rounded, color: colors.onSurface.withOpacity(0.72), size: 18),
          ),
        ],
      ),
    );
  }
}

class FloatingChip extends StatelessWidget {
  final String label;
  final IconData icon;
  const FloatingChip({super.key, required this.label, required this.icon});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      decoration: BoxDecoration(
        color: colors.surface.withOpacity(0.82),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: colors.outline),
        boxShadow: [softShadow(context)],
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: colors.onSurface.withOpacity(0.70), size: 13),
        const SizedBox(width: 6),
        Text(label, style: TextStyle(color: colors.onSurface.withOpacity(0.70), fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

class InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const InfoCard({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: colors.outline)),
        child: Row(
          children: [
            Icon(icon, color: colors.onSurface.withOpacity(0.54), size: 22),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(color: colors.onSurface, fontSize: 14, fontWeight: FontWeight.w650)),
                const SizedBox(height: 3),
                Text(subtitle, style: TextStyle(color: colors.onSurface.withOpacity(0.40), fontSize: 11, height: 1.35)),
              ]),
            ),
            Icon(Icons.chevron_right_rounded, color: colors.onSurface.withOpacity(0.25), size: 18),
          ],
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(top: 4, bottom: 8),
      child: Text(text, style: TextStyle(color: colors.onSurface.withOpacity(0.36), fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.6)),
    );
  }
}

class PrimaryCapsuleButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const PrimaryCapsuleButton({super.key, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(color: colors.onSurface, borderRadius: BorderRadius.circular(28)),
        child: Center(child: Text(label, style: TextStyle(color: Theme.of(context).scaffoldBackgroundColor, fontSize: 14, fontWeight: FontWeight.w700))),
      ),
    );
  }
}

BoxShadow softShadow(BuildContext context) {
  final dark = Theme.of(context).brightness == Brightness.dark;
  return BoxShadow(
    color: Colors.black.withOpacity(dark ? 0.56 : 0.08),
    blurRadius: 24,
    offset: const Offset(0, 10),
  );
}

String themeLabel(ThemeMode mode) {
  return switch (mode) {
    ThemeMode.system => '跟随系统',
    ThemeMode.light => '浅色模式',
    ThemeMode.dark => '深色模式',
  };
}

void showSoon(BuildContext context) {
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Text('功能开发中，入口已预留。'), behavior: SnackBarBehavior.floating),
  );
}
