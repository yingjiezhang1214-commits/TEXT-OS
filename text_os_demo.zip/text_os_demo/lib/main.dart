import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:crypto/crypto.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarDividerColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  final controller = await XinWeiController.create();
  runApp(XinWeiApp(controller: controller));
}

class ChapterInfo {
  final int index;
  final String title;
  final int startByteOffset;
  final int endByteOffset;
  final int wordCount;

  const ChapterInfo({
    required this.index,
    required this.title,
    required this.startByteOffset,
    required this.endByteOffset,
    required this.wordCount,
  });

  Map<String, dynamic> toJson() => {
        'index': index,
        'title': title,
        'startByteOffset': startByteOffset,
        'endByteOffset': endByteOffset,
        'wordCount': wordCount,
      };

  static ChapterInfo fromJson(Map<String, dynamic> json) => ChapterInfo(
        index: json['index'] as int? ?? 0,
        title: json['title'] as String? ?? '未命名章节',
        startByteOffset: json['startByteOffset'] as int? ?? 0,
        endByteOffset: json['endByteOffset'] as int? ?? 0,
        wordCount: json['wordCount'] as int? ?? 0,
      );
}

class XinWeiBook {
  final String id;
  final String title;
  final String filePath;
  final String encoding;
  final List<ChapterInfo> chapters;
  final int progressChapterIndex;
  final double progressScrollOffset;
  final DateTime importedAt;
  final DateTime updatedAt;
  final bool isDemo;

  const XinWeiBook({
    required this.id,
    required this.title,
    required this.filePath,
    required this.encoding,
    required this.chapters,
    required this.progressChapterIndex,
    required this.progressScrollOffset,
    required this.importedAt,
    required this.updatedAt,
    this.isDemo = false,
  });

  int get totalWords => chapters.fold(0, (sum, c) => sum + c.wordCount);
  int get chapterCount => chapters.length;

  XinWeiBook copyWith({
    int? progressChapterIndex,
    double? progressScrollOffset,
    DateTime? updatedAt,
  }) =>
      XinWeiBook(
        id: id,
        title: title,
        filePath: filePath,
        encoding: encoding,
        chapters: chapters,
        progressChapterIndex: progressChapterIndex ?? this.progressChapterIndex,
        progressScrollOffset: progressScrollOffset ?? this.progressScrollOffset,
        importedAt: importedAt,
        updatedAt: updatedAt ?? this.updatedAt,
        isDemo: isDemo,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'filePath': filePath,
        'encoding': encoding,
        'chapters': chapters.map((e) => e.toJson()).toList(),
        'progressChapterIndex': progressChapterIndex,
        'progressScrollOffset': progressScrollOffset,
        'importedAt': importedAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isDemo': isDemo,
      };

  static XinWeiBook fromJson(Map<String, dynamic> json) => XinWeiBook(
        id: json['id'] as String,
        title: json['title'] as String? ?? '未命名文本',
        filePath: json['filePath'] as String? ?? '',
        encoding: json['encoding'] as String? ?? 'utf8',
        chapters: ((json['chapters'] as List?) ?? [])
            .whereType<Map>()
            .map((e) => ChapterInfo.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        progressChapterIndex: json['progressChapterIndex'] as int? ?? 0,
        progressScrollOffset: (json['progressScrollOffset'] as num?)?.toDouble() ?? 0,
        importedAt: DateTime.tryParse(json['importedAt'] as String? ?? '') ?? DateTime.now(),
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ?? DateTime.now(),
        isDemo: json['isDemo'] as bool? ?? false,
      );
}

class ImportResult {
  final String title;
  final String filePath;
  final String fileHash;
  final String encoding;
  final List<ChapterInfo> chapters;

  const ImportResult({
    required this.title,
    required this.filePath,
    required this.fileHash,
    required this.encoding,
    required this.chapters,
  });
}

class ParseRequest {
  final String filePath;
  final String fileHash;
  final String title;

  const ParseRequest({required this.filePath, required this.fileHash, required this.title});
}

class TxtImportService {
  Future<FilePickerResult?> pickFile() async {
    return FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['txt']);
  }

  Future<ImportResult> processAndParse(FilePickerResult pickerResult) async {
    final path = pickerResult.files.single.path;
    if (path == null) {
      throw const FormatException('无法读取所选文件路径。');
    }

    final originalFile = File(path);
    final fileName = pickerResult.files.single.name;
    final rawTitle = fileName.replaceAll(RegExp(r'\.txt$', caseSensitive: false), '');

    final digest = await md5.bind(originalFile.openRead()).first;
    final md5Hash = digest.toString();

    final docDir = await getApplicationDocumentsDirectory();
    final booksDir = Directory(p.join(docDir.path, 'books'));
    if (!await booksDir.exists()) {
      await booksDir.create(recursive: true);
    }

    final sandboxFile = File(p.join(booksDir.path, '$md5Hash.txt'));
    if (!await sandboxFile.exists()) {
      await originalFile.copy(sandboxFile.path);
    }

    return compute(
      parseTxtInIsolate,
      ParseRequest(filePath: sandboxFile.path, fileHash: md5Hash, title: rawTitle),
    );
  }
}

@pragma('vm:entry-point')
Future<ImportResult> parseTxtInIsolate(ParseRequest req) async {
  final file = File(req.filePath);
  final headerRegExp = RegExp(r'^(第[零一二三四五六七八九十百千万\d]+[章节回卷].*|序章.*|楔子.*|前言.*)$');

  final chapters = <ChapterInfo>[];
  final lineEndOffsets = <int>[];
  var currentByteOffset = 0;
  var chapterStartOffset = 0;
  var chapterTitle = '开篇';
  var chapterWordCount = 0;
  var headerHits = 0;
  var leftover = <int>[];

  Future<void> consumeLine(List<int> lineBytes) async {
    final lineStart = currentByteOffset;
    final lineLength = lineBytes.length;
    String line;
    try {
      line = utf8.decode(lineBytes);
    } catch (_) {
      throw const FormatException('当前版本仅支持 UTF-8 编码文本。');
    }

    final trimmed = line.replaceFirst('\ufeff', '').trim();
    final isHeader = headerRegExp.hasMatch(trimmed);

    if (isHeader) {
      headerHits++;
      if (lineStart > chapterStartOffset || chapters.isNotEmpty) {
        final length = lineStart - chapterStartOffset;
        if (length > 0) {
          chapters.add(
            ChapterInfo(
              index: chapters.length,
              title: chapterTitle,
              startByteOffset: chapterStartOffset,
              endByteOffset: lineStart,
              wordCount: chapterWordCount,
            ),
          );
        }
      }
      chapterTitle = trimmed.isEmpty ? '未命名章节' : trimmed;
      chapterStartOffset = lineStart;
      chapterWordCount = trimmed.length;
    } else {
      chapterWordCount += trimmed.length;
    }

    currentByteOffset += lineLength;
    lineEndOffsets.add(currentByteOffset);
  }

  await for (final chunk in file.openRead()) {
    var i = 0;
    while (i < chunk.length) {
      final lfIndex = chunk.indexOf(10, i);
      if (lfIndex == -1) {
        leftover.addAll(chunk.sublist(i));
        break;
      }

      List<int> lineBytes;
      if (leftover.isEmpty) {
        lineBytes = chunk.sublist(i, lfIndex + 1);
      } else {
        leftover.addAll(chunk.sublist(i, lfIndex + 1));
        lineBytes = List<int>.from(leftover);
        leftover.clear();
      }
      await consumeLine(lineBytes);
      i = lfIndex + 1;
    }
  }

  if (leftover.isNotEmpty) {
    await consumeLine(List<int>.from(leftover));
    leftover.clear();
  }

  final totalBytes = currentByteOffset;
  if (totalBytes == 0) {
    throw const FormatException('文本为空，无法导入。');
  }

  final lastLength = totalBytes - chapterStartOffset;
  if (lastLength > 0) {
    chapters.add(
      ChapterInfo(
        index: chapters.length,
        title: chapterTitle,
        startByteOffset: chapterStartOffset,
        endByteOffset: totalBytes,
        wordCount: chapterWordCount,
      ),
    );
  }

  final safeChapters = (headerHits == 0 && totalBytes > 30000)
      ? _fallbackLineSafeChunking(totalBytes: totalBytes, lineEndOffsets: lineEndOffsets)
      : chapters;

  return ImportResult(
    title: req.title,
    filePath: req.filePath,
    fileHash: req.fileHash,
    encoding: 'utf8',
    chapters: safeChapters.isEmpty
        ? [
            ChapterInfo(
              index: 0,
              title: '全文',
              startByteOffset: 0,
              endByteOffset: totalBytes,
              wordCount: totalBytes ~/ 3,
            )
          ]
        : safeChapters,
  );
}

List<ChapterInfo> _fallbackLineSafeChunking({required int totalBytes, required List<int> lineEndOffsets}) {
  const targetChunkSize = 20000;
  if (lineEndOffsets.isEmpty) {
    return [
      ChapterInfo(
        index: 0,
        title: '全文',
        startByteOffset: 0,
        endByteOffset: totalBytes,
        wordCount: totalBytes ~/ 3,
      )
    ];
  }

  final result = <ChapterInfo>[];
  var start = 0;
  var nextTarget = targetChunkSize;

  for (final end in lineEndOffsets) {
    if (end >= nextTarget && end > start) {
      result.add(
        ChapterInfo(
          index: result.length,
          title: '第 ${result.length + 1} 部分',
          startByteOffset: start,
          endByteOffset: end,
          wordCount: (end - start) ~/ 3,
        ),
      );
      start = end;
      nextTarget = start + targetChunkSize;
    }
  }

  if (start < totalBytes) {
    result.add(
      ChapterInfo(
        index: result.length,
        title: '第 ${result.length + 1} 部分',
        startByteOffset: start,
        endByteOffset: totalBytes,
        wordCount: (totalBytes - start) ~/ 3,
      ),
    );
  }
  return result;
}

class ChapterContent {
  final XinWeiBook book;
  final ChapterInfo chapter;
  final List<String> paragraphs;

  const ChapterContent({required this.book, required this.chapter, required this.paragraphs});

  int get chapterIndex => chapter.index;
  int get maxChapterIndex => book.chapters.isEmpty ? 0 : book.chapters.length - 1;
}

class ReaderException implements Exception {
  final String message;
  const ReaderException(this.message);
  @override
  String toString() => message;
}

class ChapterReadService {
  Future<ChapterContent> loadChapter(XinWeiBook book, int chapterIndex) async {
    if (book.isDemo) {
      return _demoChapter(book, chapterIndex);
    }

    if (chapterIndex < 0 || chapterIndex >= book.chapters.length) {
      throw const ReaderException('章节索引越界或损坏。');
    }
    final chapter = book.chapters[chapterIndex];
    final length = chapter.endByteOffset - chapter.startByteOffset;
    if (length <= 0) {
      throw const ReaderException('章节长度异常，解析可能已损坏。');
    }

    final file = File(book.filePath);
    if (!await file.exists()) {
      throw const ReaderException('源文件丢失，请回到书架删除后重新导入。');
    }

    final raf = await file.open(mode: FileMode.read);
    try {
      await raf.setPosition(chapter.startByteOffset);
      final bytes = await raf.read(length);
      final text = utf8.decode(bytes);
      final paragraphs = _cleanParagraphs(text, chapter.title);
      return ChapterContent(book: book, chapter: chapter, paragraphs: paragraphs);
    } on FormatException {
      throw const ReaderException('文本解码失败，当前仅支持 UTF-8 编码。');
    } finally {
      await raf.close();
    }
  }

  ChapterContent _demoChapter(XinWeiBook book, int chapterIndex) {
    final chapter = book.chapters[chapterIndex.clamp(0, book.chapters.length - 1)];
    final paragraphs = chapterIndex == 0
        ? [
            '那晚弘大街头的风很凉，他突然在人群中转过身。这里陷入了长久的沉默。',
            '这不是一个游戏提示，也不是一段固定剧情。XinWei 会把文字变成可以被进入的世界。',
          ]
        : [
            '世界线已偏移。他低下头，孤身走向了那场没有终点的暴雨。',
            '镜像世界暂时只是入口，真正的角色和 AI 生成会在后续版本接入。',
          ];
    return ChapterContent(book: book, chapter: chapter, paragraphs: paragraphs);
  }

  List<String> _cleanParagraphs(String text, String title) {
    final paragraphs = text
        .split(RegExp(r'\n+'))
        .map((e) => e.trim().replaceFirst('\ufeff', ''))
        .where((e) => e.isNotEmpty)
        .toList();
    if (paragraphs.isNotEmpty) {
      String normalize(String s) => s.replaceAll(RegExp(r'\s+'), '').replaceFirst('\ufeff', '');
      if (normalize(paragraphs.first) == normalize(title)) {
        paragraphs.removeAt(0);
      }
    }
    return paragraphs;
  }
}

class XinWeiController extends ChangeNotifier {
  final SharedPreferences prefs;
  bool hasSeenOnboarding;
  ThemeMode themeMode;
  double fontSize;
  double lineHeight;
  double paragraphSpacing;
  bool vibrationEnabled;
  bool lowPerformanceMode;
  final List<XinWeiBook> books;
  AppPage startPage = AppPage.home;

  XinWeiController._({
    required this.prefs,
    required this.hasSeenOnboarding,
    required this.themeMode,
    required this.fontSize,
    required this.lineHeight,
    required this.paragraphSpacing,
    required this.vibrationEnabled,
    required this.lowPerformanceMode,
    required this.books,
  });

  static Future<XinWeiController> create() async {
    final prefs = await SharedPreferences.getInstance();
    final themeIndex = (prefs.getInt('theme_mode') ?? 2).clamp(0, 2).toInt();
    final rawBooks = prefs.getStringList('books') ?? [];
    final books = rawBooks
        .map((e) {
          try {
            return XinWeiBook.fromJson(jsonDecode(e) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<XinWeiBook>()
        .toList();

    if (books.isEmpty) {
      books.add(
        XinWeiBook(
          id: 'demo_hongdae',
          title: '弘大街头',
          filePath: '',
          encoding: 'utf8',
          chapters: const [
            ChapterInfo(index: 0, title: '正史片段', startByteOffset: 0, endByteOffset: 1, wordCount: 120),
            ChapterInfo(index: 1, title: '镜像片段', startByteOffset: 1, endByteOffset: 2, wordCount: 90),
          ],
          progressChapterIndex: 0,
          progressScrollOffset: 0,
          importedAt: DateTime.now(),
          updatedAt: DateTime.now(),
          isDemo: true,
        ),
      );
    }

    final controller = XinWeiController._(
      prefs: prefs,
      hasSeenOnboarding: prefs.getBool('has_seen_onboarding') ?? false,
      themeMode: ThemeMode.values[themeIndex],
      fontSize: prefs.getDouble('font_size') ?? 16.5,
      lineHeight: prefs.getDouble('line_height') ?? 1.8,
      paragraphSpacing: prefs.getDouble('paragraph_spacing') ?? 16,
      vibrationEnabled: prefs.getBool('vibration_enabled') ?? true,
      lowPerformanceMode: prefs.getBool('low_performance') ?? false,
      books: books,
    );
    controller.syncSystemBars();
    return controller;
  }

  Future<void> finishOnboarding({AppPage target = AppPage.home}) async {
    hasSeenOnboarding = true;
    startPage = target;
    await prefs.setBool('has_seen_onboarding', true);
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode = mode;
    await prefs.setInt('theme_mode', mode.index);
    syncSystemBars();
    notifyListeners();
  }

  Future<void> setFontSize(double value) async {
    fontSize = value;
    await prefs.setDouble('font_size', value);
    notifyListeners();
  }

  Future<void> setLineHeight(double value) async {
    lineHeight = value;
    await prefs.setDouble('line_height', value);
    notifyListeners();
  }

  Future<void> setParagraphSpacing(double value) async {
    paragraphSpacing = value;
    await prefs.setDouble('paragraph_spacing', value);
    notifyListeners();
  }

  Future<void> setVibration(bool value) async {
    vibrationEnabled = value;
    await prefs.setBool('vibration_enabled', value);
    notifyListeners();
  }

  Future<void> setLowPerformance(bool value) async {
    lowPerformanceMode = value;
    await prefs.setBool('low_performance', value);
    notifyListeners();
  }

  Future<ImportOutcome> addImportedBook(ImportResult result) async {
    final existingIndex = books.indexWhere((b) => b.id == result.fileHash);
    if (existingIndex != -1) {
      return ImportOutcome(book: books[existingIndex], isNew: false);
    }
    final now = DateTime.now();
    final book = XinWeiBook(
      id: result.fileHash,
      title: result.title.isEmpty ? '未命名文本' : result.title,
      filePath: result.filePath,
      encoding: result.encoding,
      chapters: result.chapters,
      progressChapterIndex: 0,
      progressScrollOffset: 0,
      importedAt: now,
      updatedAt: now,
    );
    books.insert(0, book);
    await _saveBooks();
    notifyListeners();
    return ImportOutcome(book: book, isNew: true);
  }

  Future<void> updateProgress(String bookId, int chapterIndex, {double scrollOffset = 0}) async {
    final index = books.indexWhere((b) => b.id == bookId);
    if (index == -1) return;
    books[index] = books[index].copyWith(
      progressChapterIndex: chapterIndex,
      progressScrollOffset: scrollOffset,
      updatedAt: DateTime.now(),
    );
    await _saveBooks();
    notifyListeners();
  }

  Future<void> clearLibrary() async {
    books.removeWhere((b) => !b.isDemo);
    await _saveBooks();
    notifyListeners();
  }

  Future<void> resetOnboarding() async {
    hasSeenOnboarding = false;
    await prefs.setBool('has_seen_onboarding', false);
    notifyListeners();
  }

  XinWeiBook? bookById(String id) {
    try {
      return books.firstWhere((b) => b.id == id);
    } catch (_) {
      return null;
    }
  }

  Future<void> _saveBooks() async {
    await prefs.setStringList('books', books.map((b) => jsonEncode(b.toJson())).toList());
  }

  void syncSystemBars() {
    final isLight = themeMode == ThemeMode.light;
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarDividerColor: Colors.transparent,
        statusBarIconBrightness: isLight ? Brightness.dark : Brightness.light,
        systemNavigationBarIconBrightness: isLight ? Brightness.dark : Brightness.light,
      ),
    );
  }
}

class ImportOutcome {
  final XinWeiBook book;
  final bool isNew;
  const ImportOutcome({required this.book, required this.isNew});
}

enum AppPage { home, reader, characters, settings }

class XinWeiApp extends StatelessWidget {
  final XinWeiController controller;
  const XinWeiApp({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: AppTheme.light,
          darkTheme: AppTheme.dark,
          themeMode: controller.themeMode,
          home: controller.hasSeenOnboarding ? XinWeiShell(controller: controller) : ViewOnboarding(controller: controller),
        );
      },
    );
  }
}

class AppTheme {
  static ThemeData get dark => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF000000),
        fontFamily: 'sans-serif',
        colorScheme: const ColorScheme.dark(
          surface: Color(0xFF0A0A0A),
          onSurface: Color(0xFFE5E5E5),
          outline: Color(0xFF1C1C1C),
          surfaceContainerHighest: Color(0xFF141414),
        ),
      );

  static ThemeData get light => ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF7F7F7),
        fontFamily: 'sans-serif',
        colorScheme: const ColorScheme.light(
          surface: Color(0xFFFFFFFF),
          onSurface: Color(0xFF222222),
          outline: Color(0xFFE0E0E0),
          surfaceContainerHighest: Color(0xFFEFEFEF),
        ),
      );
}

class ViewOnboarding extends StatefulWidget {
  final XinWeiController controller;
  const ViewOnboarding({super.key, required this.controller});

  @override
  State<ViewOnboarding> createState() => _ViewOnboardingState();
}

class _ViewOnboardingState extends State<ViewOnboarding> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _finish({AppPage target = AppPage.home}) async {
    await widget.controller.finishOnboarding(target: target);
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      body: Stack(
        children: [
          PageView(
            controller: _pageController,
            onPageChanged: (i) => setState(() => _currentPage = i),
            children: [
              _buildPage('文本即世界', '导入一部本地小说，\nXinWei 会把它拆成章节、段落与可进入的阅读场。'),
              _buildPage('正史与镜像', '你可以安静阅读原文，\n也可以在未来创建角色，切入平行世界。'),
              _buildPage('文本即私有领地', '本地小说默认绝不上传。\n只有你主动启用 AI 跃迁时，相关上下文才会发送到你配置的节点。'),
            ],
          ),
          Positioned(
            bottom: MediaQuery.of(context).padding.bottom + 40,
            left: 32,
            right: 32,
            child: _currentPage == 2
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _PrimaryButton(label: '进入示例世界', onTap: () => _finish()),
                      const SizedBox(height: 12),
                      _GhostButton(label: '自定义角色', onTap: () => _finish(target: AppPage.characters)),
                    ],
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(onPressed: () => _finish(), child: Text('跳过', style: TextStyle(color: colors.onSurface.withOpacity(0.4)))),
                      GestureDetector(
                        onTap: () => _pageController.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.ease),
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(shape: BoxShape.circle, color: colors.onSurface.withOpacity(0.1)),
                          child: Icon(Icons.arrow_forward_rounded, color: colors.onSurface, size: 20),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildPage(String title, String desc) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.all(40),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: colors.onSurface, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 24),
          Text(title, style: TextStyle(color: colors.onSurface, fontSize: 28, fontWeight: FontWeight.w700, letterSpacing: 1)),
          const SizedBox(height: 16),
          Text(desc, style: TextStyle(color: colors.onSurface.withOpacity(0.55), fontSize: 15, height: 1.8)),
        ],
      ),
    );
  }
}

class XinWeiShell extends StatefulWidget {
  final XinWeiController controller;
  const XinWeiShell({super.key, required this.controller});

  @override
  State<XinWeiShell> createState() => _XinWeiShellState();
}

class _XinWeiShellState extends State<XinWeiShell> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late AppPage _currentPage;
  String? _currentBookId;

  @override
  void initState() {
    super.initState();
    _currentPage = widget.controller.startPage;
  }

  void _navigateTo(AppPage page) {
    setState(() => _currentPage = page);
  }

  void _openBook(XinWeiBook book) {
    setState(() {
      _currentBookId = book.id;
      _currentPage = AppPage.reader;
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      key: _scaffoldKey,
      extendBody: true,
      extendBodyBehindAppBar: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      drawer: V2Drawer(
        controller: widget.controller,
        currentPage: _currentPage,
        onNavigate: (page) {
          Navigator.pop(context);
          _navigateTo(page);
        },
      ),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight),
        child: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: AppBar(
              backgroundColor: Theme.of(context).scaffoldBackgroundColor.withOpacity(0.58),
              elevation: 0,
              scrolledUnderElevation: 0,
              leading: IconButton(
                icon: Icon(Icons.align_horizontal_left_rounded, color: colors.onSurface.withOpacity(0.48), size: 20),
                onPressed: () => _scaffoldKey.currentState?.openDrawer(),
              ),
              centerTitle: true,
              title: Text(_titleForPage(), style: TextStyle(color: colors.onSurface.withOpacity(0.56), fontSize: 13, letterSpacing: 0.5)),
              actions: [
                if (_currentPage == AppPage.reader)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Center(child: Text('正史', style: TextStyle(color: colors.onSurface.withOpacity(0.3), fontSize: 11))),
                  ),
              ],
            ),
          ),
        ),
      ),
      body: _buildBody(),
    );
  }

  String _titleForPage() {
    switch (_currentPage) {
      case AppPage.home:
        return '书架';
      case AppPage.reader:
        final b = _currentBookId == null ? null : widget.controller.bookById(_currentBookId!);
        return b?.title ?? '阅读';
      case AppPage.characters:
        return '角色档案';
      case AppPage.settings:
        return '系统偏好设置';
    }
  }

  Widget _buildBody() {
    switch (_currentPage) {
      case AppPage.home:
        return ViewHome(controller: widget.controller, onOpenBook: _openBook);
      case AppPage.reader:
        final bookId = _currentBookId;
        if (bookId == null) {
          return ViewHome(controller: widget.controller, onOpenBook: _openBook);
        }
        return ReaderView(controller: widget.controller, bookId: bookId, onExit: () => _navigateTo(AppPage.home));
      case AppPage.characters:
        return const ViewCharacters();
      case AppPage.settings:
        return ViewSettings(controller: widget.controller);
    }
  }
}

class ViewHome extends StatefulWidget {
  final XinWeiController controller;
  final ValueChanged<XinWeiBook> onOpenBook;
  const ViewHome({super.key, required this.controller, required this.onOpenBook});

  @override
  State<ViewHome> createState() => _ViewHomeState();
}

class _ViewHomeState extends State<ViewHome> {
  final TxtImportService _importService = TxtImportService();
  String? _loadingState;

  Future<void> _handleImportBook() async {
    final picked = await _importService.pickFile();
    if (picked == null) return;
    try {
      setState(() => _loadingState = '读取文件与散列计算中...');
      setState(() => _loadingState = '后台引擎解析章节中...');
      final parsed = await _importService.processAndParse(picked);
      setState(() => _loadingState = '生成本地书架索引...');
      final outcome = await widget.controller.addImportedBook(parsed);
      if (!mounted) return;
      _showSnack(outcome.isNew ? '导入成功，共切分 ${parsed.chapters.length} 个章节' : '该文本已存在于书架中');
    } on FormatException catch (e) {
      if (!mounted) return;
      _showError('导入失败', e.message.isEmpty ? '当前仅支持 UTF-8 编码文本。' : e.message);
    } catch (_) {
      if (!mounted) return;
      _showError('导入中断', '发生未知异常，请换一个 UTF-8 编码的 TXT 重试。');
    } finally {
      if (mounted) setState(() => _loadingState = null);
    }
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(fontSize: 13)),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _showError(String title, String message) {
    final colors = Theme.of(context).colorScheme;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: colors.surfaceContainerHighest,
        title: Text(title, style: TextStyle(color: colors.onSurface, fontSize: 16, fontWeight: FontWeight.w700)),
        content: Text(message, style: TextStyle(color: colors.onSurface.withOpacity(0.65), fontSize: 13, height: 1.5)),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text('明白了', style: TextStyle(color: colors.onSurface)))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Stack(
      children: [
        AnimatedBuilder(
          animation: widget.controller,
          builder: (context, _) {
            final books = widget.controller.books;
            return ListView(
              padding: EdgeInsets.only(
                top: kToolbarHeight + MediaQuery.of(context).padding.top + 24,
                bottom: MediaQuery.of(context).padding.bottom + 40,
                left: 20,
                right: 20,
              ),
              children: [
                GestureDetector(
                  onTap: _handleImportBook,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 20),
                    margin: const EdgeInsets.only(bottom: 24),
                    decoration: BoxDecoration(
                      color: colors.onSurface.withOpacity(0.025),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: colors.outline),
                    ),
                    child: Center(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.add_rounded, color: colors.onSurface.withOpacity(0.5), size: 18),
                          const SizedBox(width: 8),
                          Text('导入本地文本 TXT', style: TextStyle(color: colors.onSurface.withOpacity(0.55), fontSize: 13)),
                        ],
                      ),
                    ),
                  ),
                ),
                ...books.map((book) => _BookCard(book: book, onTap: () => widget.onOpenBook(book))),
              ],
            );
          },
        ),
        if (_loadingState != null)
          Positioned.fill(
            child: Container(
              color: Colors.black.withOpacity(0.62),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                  decoration: BoxDecoration(
                    color: colors.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: colors.outline),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(strokeWidth: 2, color: colors.onSurface.withOpacity(0.55)),
                      const SizedBox(height: 18),
                      Text(_loadingState!, style: TextStyle(color: colors.onSurface.withOpacity(0.75), fontSize: 13)),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _BookCard extends StatelessWidget {
  final XinWeiBook book;
  final VoidCallback onTap;
  const _BookCard({required this.book, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final progress = book.chapterCount == 0 ? 0.0 : (book.progressChapterIndex + 1) / book.chapterCount;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: colors.outline),
        ),
        child: Row(
          children: [
            Container(
              width: 60,
              height: 82,
              decoration: BoxDecoration(color: colors.onSurface.withOpacity(0.05), borderRadius: BorderRadius.circular(10)),
              child: Icon(book.isDemo ? Icons.auto_stories_rounded : Icons.menu_book_rounded, color: colors.onSurface.withOpacity(0.22)),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(book.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: colors.onSurface, fontSize: 16, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text('${book.chapterCount} 章 · ${book.totalWords} 字 · UTF-8', style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 11)),
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(999),
                    child: LinearProgressIndicator(
                      value: progress.clamp(0.0, 1.0),
                      minHeight: 3,
                      backgroundColor: colors.onSurface.withOpacity(0.08),
                      valueColor: AlwaysStoppedAnimation<Color>(colors.onSurface.withOpacity(0.36)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ReaderView extends StatefulWidget {
  final XinWeiController controller;
  final String bookId;
  final VoidCallback onExit;
  const ReaderView({super.key, required this.controller, required this.bookId, required this.onExit});

  @override
  State<ReaderView> createState() => _ReaderViewState();
}

class _ReaderViewState extends State<ReaderView> {
  final _scrollController = ScrollController();
  final _readService = ChapterReadService();
  ChapterContent? _chapter;
  String? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadCurrent();
  }

  Future<void> _loadCurrent() async {
    final book = widget.controller.bookById(widget.bookId);
    if (book == null) {
      setState(() {
        _error = '找不到这本书。';
        _loading = false;
      });
      return;
    }
    await _loadChapter(book.progressChapterIndex);
  }

  Future<void> _loadChapter(int index) async {
    final book = widget.controller.bookById(widget.bookId);
    if (book == null) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final content = await _readService.loadChapter(book, index);
      await widget.controller.updateProgress(book.id, content.chapterIndex);
      if (!mounted) return;
      setState(() {
        _chapter = content;
        _loading = false;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _scrollController.hasClients) {
          _scrollController.jumpTo(0);
        }
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Stack(
      children: [
        if (_loading)
          Center(child: CircularProgressIndicator(strokeWidth: 2, color: colors.onSurface.withOpacity(0.5)))
        else if (_error != null)
          Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Text(_error!, textAlign: TextAlign.center, style: TextStyle(color: colors.onSurface.withOpacity(0.55), fontSize: 13, height: 1.5)),
            ),
          )
        else if (_chapter != null)
          ListView.builder(
            controller: _scrollController,
            padding: EdgeInsets.only(
              top: kToolbarHeight + MediaQuery.of(context).padding.top + 28,
              left: 20,
              right: 20,
              bottom: MediaQuery.of(context).padding.bottom + 120,
            ),
            itemCount: _chapter!.paragraphs.length + 1,
            itemBuilder: (context, index) {
              if (index == 0) return Padding(padding: const EdgeInsets.only(bottom: 24), child: SystemLine(_chapter!.chapter.title));
              return Padding(
                padding: EdgeInsets.only(bottom: widget.controller.paragraphSpacing),
                child: CanonCard(text: _chapter!.paragraphs[index - 1], controller: widget.controller),
              );
            },
          ),
        Positioned(left: 18, right: 18, bottom: MediaQuery.of(context).padding.bottom + 16, child: _navConsole(colors)),
      ],
    );
  }

  Widget _navConsole(ColorScheme colors) {
    final curr = _chapter?.chapterIndex ?? 0;
    final max = _chapter?.maxChapterIndex ?? 0;
    final canPrev = _chapter != null && curr > 0;
    final canNext = _chapter != null && curr < max;
    return Container(
      height: 50,
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: colors.outline),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.35 : 0.08), blurRadius: 20, offset: const Offset(0, 6))],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(onPressed: canPrev ? () => _loadChapter(curr - 1) : null, icon: Icon(Icons.arrow_back_ios_rounded, size: 16, color: colors.onSurface.withOpacity(canPrev ? 0.7 : 0.2))),
          TextButton(onPressed: widget.onExit, child: Text('回到书架', style: TextStyle(color: colors.onSurface.withOpacity(0.55), fontSize: 13, fontWeight: FontWeight.w700))),
          IconButton(onPressed: canNext ? () => _loadChapter(curr + 1) : null, icon: Icon(Icons.arrow_forward_ios_rounded, size: 16, color: colors.onSurface.withOpacity(canNext ? 0.7 : 0.2))),
        ],
      ),
    );
  }
}

class SystemLine extends StatelessWidget {
  final String text;
  const SystemLine(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Center(child: Text('—— $text ——', style: TextStyle(color: colors.onSurface.withOpacity(0.28), fontSize: 10, letterSpacing: 1.5)));
  }
}

class CanonCard extends StatelessWidget {
  final String text;
  final XinWeiController controller;
  const CanonCard({super.key, required this.text, required this.controller});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Text(
      text,
      style: TextStyle(
        color: colors.onSurface.withOpacity(0.9),
        fontSize: controller.fontSize,
        height: controller.lineHeight,
        fontFamily: 'serif',
        letterSpacing: 0.15,
      ),
    );
  }
}

class ViewCharacters extends StatelessWidget {
  const ViewCharacters({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return ListView(
      padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 24, left: 20, right: 20),
      children: [
        _Panel(title: '默认角色档案', subtitle: '新角色 · 旁观者身份 · 未绑定世界线', icon: Icons.person_outline_rounded),
        const SizedBox(height: 14),
        _Panel(title: '自建角色', subtitle: 'V6 将开放姓名、阵营、能力、与原著关系。', icon: Icons.person_add_alt_1_rounded),
        const SizedBox(height: 14),
        Text('当前版本只保留角色入口，真正角色引擎会在 V6 接入。', style: TextStyle(color: colors.onSurface.withOpacity(0.36), fontSize: 12, height: 1.5)),
      ],
    );
  }
}

class ViewSettings extends StatelessWidget {
  final XinWeiController controller;
  const ViewSettings({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return ListView(
          padding: EdgeInsets.only(top: kToolbarHeight + MediaQuery.of(context).padding.top + 24, bottom: 40, left: 20, right: 20),
          children: [
            _SectionTitle('外观设置'),
            _ChoiceRow(
              title: '主题模式',
              options: const ['跟随', '浅色', '深色'],
              selected: controller.themeMode == ThemeMode.system ? 0 : controller.themeMode == ThemeMode.light ? 1 : 2,
              onTap: (i) => controller.setThemeMode([ThemeMode.system, ThemeMode.light, ThemeMode.dark][i]),
            ),
            _SliderRow(title: '字体大小', value: controller.fontSize, min: 14, max: 22, onChanged: controller.setFontSize),
            _SliderRow(title: '行距', value: controller.lineHeight, min: 1.4, max: 2.2, onChanged: controller.setLineHeight),
            _SliderRow(title: '段落间距', value: controller.paragraphSpacing, min: 8, max: 28, onChanged: controller.setParagraphSpacing),
            _SectionTitle('阅读与动画'),
            _SwitchRow(title: '震动反馈', value: controller.vibrationEnabled, onChanged: controller.setVibration),
            _SwitchRow(title: '低性能模式', value: controller.lowPerformanceMode, onChanged: controller.setLowPerformance),
            _SectionTitle('数据与隐私'),
            _ActionRow(title: '重置引导页', subtitle: '下次启动重新显示首次引导', onTap: controller.resetOnboarding),
            _ActionRow(title: '清除导入书籍', subtitle: '保留示例文本，删除本地书架记录', onTap: controller.clearLibrary),
            _SectionTitle('高级与实验'),
            _Panel(title: 'AI 接入', subtitle: 'V7 接入 API，当前仅保留入口。', icon: Icons.api_rounded),
            const SizedBox(height: 12),
            _Panel(title: '平行世界入口', subtitle: 'V6 之后启用角色与世界线规则。', icon: Icons.auto_awesome_rounded),
            const SizedBox(height: 12),
            _Panel(title: '游客模式', subtitle: '当前无需登录。未来登录只用于云同步。', icon: Icons.account_circle_outlined),
          ],
        );
      },
    );
  }
}

class V2Drawer extends StatelessWidget {
  final XinWeiController controller;
  final AppPage currentPage;
  final ValueChanged<AppPage> onNavigate;
  const V2Drawer({super.key, required this.controller, required this.currentPage, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Drawer(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
              child: Text('XINWEI', style: TextStyle(color: colors.onSurface.withOpacity(0.38), fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  _DrawerItem(icon: Icons.menu_book_rounded, title: '书架', active: currentPage == AppPage.home, onTap: () => onNavigate(AppPage.home)),
                  _DrawerItem(icon: Icons.timeline_rounded, title: '阅读流', active: currentPage == AppPage.reader, onTap: () => onNavigate(AppPage.reader)),
                  _DrawerItem(icon: Icons.person_outline_rounded, title: '角色档案', active: currentPage == AppPage.characters, onTap: () => onNavigate(AppPage.characters)),
                  _DrawerItem(icon: Icons.tune_rounded, title: '设置', active: currentPage == AppPage.settings, onTap: () => onNavigate(AppPage.settings)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: colors.outline)),
                child: Row(
                  children: [
                    Icon(Icons.account_circle_outlined, color: colors.onSurface.withOpacity(0.45), size: 22),
                    const SizedBox(width: 10),
                    Expanded(child: Text('游客模式', style: TextStyle(color: colors.onSurface.withOpacity(0.62), fontSize: 13))),
                    Text('登录', style: TextStyle(color: colors.onSurface.withOpacity(0.35), fontSize: 12)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool active;
  final VoidCallback onTap;
  const _DrawerItem({required this.icon, required this.title, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return ListTile(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      tileColor: active ? colors.surface : Colors.transparent,
      leading: Icon(icon, color: colors.onSurface.withOpacity(active ? 0.68 : 0.28), size: 18),
      title: Text(title, style: TextStyle(color: colors.onSurface.withOpacity(active ? 0.68 : 0.38), fontSize: 13)),
      dense: true,
      onTap: onTap,
    );
  }
}

class _Panel extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  const _Panel({required this.title, required this.subtitle, required this.icon});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: colors.outline)),
      child: Row(
        children: [
          Icon(icon, color: colors.onSurface.withOpacity(0.5), size: 22),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(color: colors.onSurface, fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(subtitle, style: TextStyle(color: colors.onSurface.withOpacity(0.45), fontSize: 12, height: 1.35)),
            ]),
          ),
        ],
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _PrimaryButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(color: colors.onSurface, borderRadius: BorderRadius.circular(24)),
        child: Center(child: Text(label, style: TextStyle(color: Theme.of(context).scaffoldBackgroundColor, fontSize: 14, fontWeight: FontWeight.w700))),
      ),
    );
  }
}

class _GhostButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _GhostButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(onTap: onTap, child: Text(label, style: TextStyle(color: colors.onSurface.withOpacity(0.48), fontSize: 13)));
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(top: 22, bottom: 10, left: 2),
      child: Text(text, style: TextStyle(color: colors.onSurface.withOpacity(0.35), fontSize: 11, fontWeight: FontWeight.w700)),
    );
  }
}

class _ChoiceRow extends StatelessWidget {
  final String title;
  final List<String> options;
  final int selected;
  final ValueChanged<int> onTap;
  const _ChoiceRow({required this.title, required this.options, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: colors.outline)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: TextStyle(color: colors.onSurface, fontSize: 13, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        Row(
          children: List.generate(
            options.length,
            (i) => Expanded(
              child: GestureDetector(
                onTap: () => onTap(i),
                child: Container(
                  margin: EdgeInsets.only(right: i == options.length - 1 ? 0 : 8),
                  padding: const EdgeInsets.symmetric(vertical: 9),
                  decoration: BoxDecoration(
                    color: i == selected
                        ? colors.onSurface.withOpacity(0.14)
                        : colors.onSurface.withOpacity(0.04),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Center(
                    child: Text(
                      options[i],
                      style: TextStyle(
                        color: colors.onSurface.withOpacity(i == selected ? 0.86 : 0.42),
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}

class _SliderRow extends StatelessWidget {
  final String title;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;
  const _SliderRow({required this.title, required this.value, required this.min, required this.max, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
      decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: colors.outline)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('$title  ${value.toStringAsFixed(1)}', style: TextStyle(color: colors.onSurface, fontSize: 13, fontWeight: FontWeight.w700)),
        Slider(value: value, min: min, max: max, onChanged: onChanged),
      ]),
    );
  }
}

class _SwitchRow extends StatelessWidget {
  final String title;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _SwitchRow({required this.title, required this.value, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: colors.outline)),
      child: SwitchListTile(value: value, onChanged: onChanged, title: Text(title, style: TextStyle(color: colors.onSurface, fontSize: 13, fontWeight: FontWeight.w700)), contentPadding: EdgeInsets.zero),
    );
  }
}

class _ActionRow extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ActionRow({required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(top: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: colors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: colors.outline)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: colors.onSurface, fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(subtitle, style: TextStyle(color: colors.onSurface.withOpacity(0.42), fontSize: 12)),
        ]),
      ),
    );
  }
}
