import '../models/anchor.dart';

class LexiconConfig {
  final String signalType;
  final FxChannel channel;
  final double intensity;
  final int durationMs;
  final RestoreMode restoreMode;

  const LexiconConfig({
    required this.signalType,
    required this.channel,
    required this.intensity,
    required this.durationMs,
    required this.restoreMode,
  });
}

const Map<String, LexiconConfig> lexicon = {
  '风': LexiconConfig(
    signalType: 'PARTICLE_SPEED_UP',
    channel: FxChannel.PARTICLE,
    intensity: 2.0,
    durationMs: 2000,
    restoreMode: RestoreMode.SMOOTH,
  ),
  '雨': LexiconConfig(
    signalType: 'EDGE_NOISE',
    channel: FxChannel.NOISE,
    intensity: 1.5,
    durationMs: 4000,
    restoreMode: RestoreMode.SMOOTH,
  ),
  '转过身': LexiconConfig(
    signalType: 'SHAKE_ONCE',
    channel: FxChannel.MATRIX,
    intensity: 1.0,
    durationMs: 200,
    restoreMode: RestoreMode.DECAY,
  ),
  '沉默': LexiconConfig(
    signalType: 'SLOW_DOWN',
    channel: FxChannel.TYPOGRAPHY,
    intensity: 3.0,
    durationMs: 3000,
    restoreMode: RestoreMode.IMMEDIATE,
  ),
};
