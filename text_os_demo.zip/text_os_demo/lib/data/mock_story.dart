import '../engine/anchor_scanner.dart';
import '../models/story_block.dart';

class MockStory {
  static const String _canonText = '那晚弘大街头的风很凉，他突然在人群中转过身。这里陷入了长久的沉默。';
  static const String _mirrorText = '世界线已偏移。他低下头，径直走向了雨中。';

  static LocalStoryBlock get canonBlock {
    return LocalStoryBlock(
      blockId: 'canon_001',
      pureText: _canonText,
      anchors: AnchorScanner.scan(_canonText),
      nextBlockId: 'mirror_001',
    );
  }

  static LocalStoryBlock get mirrorBlock {
    return LocalStoryBlock(
      blockId: 'mirror_001',
      pureText: _mirrorText,
      anchors: AnchorScanner.scan(_mirrorText),
    );
  }
}
