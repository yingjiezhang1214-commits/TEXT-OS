import 'dart:math';
import 'package:flutter/material.dart';

class ParticlePainter extends CustomPainter {
  final double time;
  final double intensity;

  static final Random _random = Random(101);
  static final List<Offset> _seeds = List.generate(
    60,
    (_) => Offset(_random.nextDouble(), _random.nextDouble()),
  );

  ParticlePainter({required this.time, required this.intensity});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.20)
      ..style = PaintingStyle.fill;

    final speedX = time * 150 * intensity;
    final speedY = time * 30 * intensity;

    for (final seed in _seeds) {
      final x = (seed.dx * size.width + speedX) % size.width;
      final y = (size.height + seed.dy * size.height - (speedY % size.height)) % size.height;

      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(pi / 12);
      canvas.drawRect(
        Rect.fromCenter(center: Offset.zero, width: 2.4 * intensity, height: 0.8),
        paint,
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant ParticlePainter oldDelegate) =>
      time != oldDelegate.time || intensity != oldDelegate.intensity;
}

class NoisePainter extends CustomPainter {
  final double time;
  final double intensity;

  static final Random _random = Random(202);
  static final List<Offset> _seeds = List.generate(
    200,
    (_) => Offset(_random.nextDouble(), _random.nextDouble()),
  );

  NoisePainter({required this.time, required this.intensity});

  @override
  void paint(Canvas canvas, Size size) {
    if (intensity <= 0) return;

    final paint = Paint()
      ..color = Colors.white.withOpacity(min(0.16 * intensity, 0.36))
      ..strokeWidth = 1.0;

    final dropSpeed = time * 800 * intensity;

    for (final seed in _seeds) {
      final x = (seed.dx * size.width + (time * 100)) % size.width;
      final y = (seed.dy * size.height + dropSpeed) % size.height;

      if (x > size.width * 0.15 &&
          x < size.width * 0.85 &&
          y > size.height * 0.25 &&
          y < size.height * 0.75) {
        continue;
      }

      canvas.drawLine(Offset(x, y), Offset(x - 2, y + 8 * intensity), paint);
    }
  }

  @override
  bool shouldRepaint(covariant NoisePainter oldDelegate) => true;
}
