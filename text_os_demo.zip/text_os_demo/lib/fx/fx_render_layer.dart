import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/engine_event.dart';
import 'fx_channels_manager.dart';
import 'painters.dart';

class FxRenderLayer extends StatefulWidget {
  final FxChannelsManager manager;
  final Stream<EngineEvent> signalStream;

  const FxRenderLayer({super.key, required this.manager, required this.signalStream});

  @override
  State<FxRenderLayer> createState() => _FxRenderLayerState();
}

class _FxRenderLayerState extends State<FxRenderLayer> with TickerProviderStateMixin {
  late final AnimationController _shakeController;
  late final AnimationController _continuousTicker;
  late final StreamSubscription<EngineEvent> _subscription;

  int _lastNonce = 0;

  @override
  void initState() {
    super.initState();

    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );

    _continuousTicker = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();

    widget.manager.addListener(_onManagerUpdate);

    _subscription = widget.signalStream.listen((event) {
      if (event is ResetAllEvent) {
        _shakeController.stop();
        _shakeController.reset();
      }
    });
  }

  void _onManagerUpdate() {
    if (widget.manager.matrixShakeNonce != _lastNonce) {
      _lastNonce = widget.manager.matrixShakeNonce;
      HapticFeedback.mediumImpact();
      _shakeController.forward(from: 0.0);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([widget.manager, _continuousTicker, _shakeController]),
      builder: (context, child) {
        final progress = _shakeController.value;
        final decay = pow(1.0 - progress, 3).toDouble();
        final shakeEnvelope = decay * (widget.manager.matrixShakeIntensity * 6.0);
        final dx = sin(progress * pi * 8) * shakeEnvelope;
        final dy = cos(progress * pi * 8) * (shakeEnvelope * 0.5);

        return Transform.translate(
          offset: Offset(dx, dy),
          child: Stack(
            fit: StackFit.expand,
            children: [
              CustomPaint(
                painter: ParticlePainter(
                  time: _continuousTicker.value,
                  intensity: widget.manager.particleIntensity,
                ),
              ),
              if (widget.manager.noiseLevel > 0.05)
                CustomPaint(
                  painter: NoisePainter(
                    time: _continuousTicker.value,
                    intensity: widget.manager.noiseLevel,
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _subscription.cancel();
    widget.manager.removeListener(_onManagerUpdate);
    _shakeController.dispose();
    _continuousTicker.dispose();
    super.dispose();
  }
}
