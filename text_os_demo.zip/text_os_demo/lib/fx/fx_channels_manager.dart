import 'dart:async';
import 'package:flutter/foundation.dart';
import '../engine/signal_bus.dart';
import '../models/anchor.dart';
import '../models/engine_event.dart';

class FxChannelsManager extends ChangeNotifier {
  late final StreamSubscription<EngineEvent> _subscription;
  final Map<FxChannel, Timer> _channelTimers = {};
  bool _isDisposed = false;

  double particleIntensity = 1.0;
  double blurRadius = 0.0;
  double noiseLevel = 0.0;
  double brightness = 1.0;

  double matrixShakeIntensity = 0.0;
  int matrixShakeNonce = 0;

  FxChannelsManager(SignalBus signalBus) {
    _subscription = signalBus.eventStream.listen(_onEngineEvent);
  }

  void _onEngineEvent(EngineEvent event) {
    if (_isDisposed) return;

    switch (event) {
      case ResetAllEvent():
        _forceResetAll();
      case FxSignalEvent(:final anchor):
        _applySignal(anchor);
      default:
        break;
    }
  }

  void _applySignal(Anchor anchor) {
    if (anchor.channel == FxChannel.TYPOGRAPHY) return;

    _channelTimers[anchor.channel]?.cancel();
    _channelTimers.remove(anchor.channel);

    switch (anchor.channel) {
      case FxChannel.PARTICLE:
        particleIntensity = anchor.intensity;
      case FxChannel.BLUR:
        blurRadius = anchor.intensity;
      case FxChannel.NOISE:
        noiseLevel = anchor.intensity;
      case FxChannel.BRIGHTNESS:
        brightness = anchor.intensity;
      case FxChannel.MATRIX:
        matrixShakeIntensity = anchor.intensity;
        matrixShakeNonce++;
      case FxChannel.TYPOGRAPHY:
        break;
    }

    notifyListeners();

    if (anchor.durationMs > 0) {
      _channelTimers[anchor.channel] = Timer(Duration(milliseconds: anchor.durationMs), () {
        if (_isDisposed) return;
        _restoreChannel(anchor.channel);
      });
    }
  }

  void _restoreChannel(FxChannel channel) {
    _channelTimers.remove(channel);

    switch (channel) {
      case FxChannel.PARTICLE:
        particleIntensity = 1.0;
      case FxChannel.BLUR:
        blurRadius = 0.0;
      case FxChannel.NOISE:
        noiseLevel = 0.0;
      case FxChannel.BRIGHTNESS:
        brightness = 1.0;
      case FxChannel.MATRIX:
      case FxChannel.TYPOGRAPHY:
        break;
    }

    notifyListeners();
  }

  void _forceResetAll() {
    for (final timer in _channelTimers.values) {
      timer.cancel();
    }
    _channelTimers.clear();

    particleIntensity = 1.0;
    blurRadius = 0.0;
    noiseLevel = 0.0;
    brightness = 1.0;

    notifyListeners();
  }

  @override
  void dispose() {
    _isDisposed = true;
    _subscription.cancel();
    for (final timer in _channelTimers.values) {
      timer.cancel();
    }
    _channelTimers.clear();
    super.dispose();
  }
}
